## Chapter One: Stop!

default c1_list = None
default c1_react = None
default c1_go = None

label chapter_01:
    call chapter_card("Chapter One", "Stop!")

    $ ash_outfit = "home"
    $ rob_outfit = "stripes"
    $ light("fire")
    scene bg home night with slowfade
    $ music("just chilling")

    "Eleven-fourteen on the seventeenth of November, and the valley outside your window is still holding on to its color."

    "Back in Wisconsin, every tree would be bare by now. Your birthday always arrived in the brown, cold, grey week when the leaves were raked and the snow hadn't bothered to show up and cover the evidence."

    "Here the maples on the hill behind Hanseo are still burning orange in the dark. You've decided, after more than a decade, to take that personally, as a gift. A birthday present, for you."

    "The floor is warm. You found the hottest patch of ondol an hour ago and you have not moved since, except to stretch your legs up on the chaise and prop one ankle on the opposite knee, which is the single most relaxing thing a human body can do and you will die on that hill."

    "The cardigan helps. Cream cable-knit, three sizes too big, sleeves pulled down to your knuckles. Under it, the sapphire silk slip with the black lace."
    
    "Because you are a grown woman who lives alone and there is no law against feeling like a sex goddess while you make ramen."

    "There's no law against the whisky sour either. Real egg white. You shook it until your arms hurt, and the foam sits on top like a cloud that has made good decisions."

    show ash neutral at lpos with dissolve

    "On the marble coffee table, between the two jar candles and the decanter, lies the notebook. This year's list."

    "Every Thanksgiving, for eight years now, you've posted the little things you're grateful for. It's due next week."
    
    "It's nearly done. But near the top, in your own handwriting, sits an entry you wrote in February and now cannot decode for love or money:"

    txt "Smile waves."

    show ash wry

    a "Smile waves. Thank you, February me. Very helpful. Great notes."

    "You stare at it. It stares back. You consider several theories, all of them stupid."

    menu:
        "Add something new to the list while you think.":
            pass

    "You tap the pen against your teeth. The candles do their small, private flickering. What goes on the list tonight?"

    menu:
        "\"The foam on a whisky sour. A tiny, boozy cloud you get to eat.\"":
            $ c1_list = "foam"
            "You write it down, then take a sip to check your work. Peer review. The foam leaves a mustache you lick off with all the dignity of a cat with cream."
        "\"Sleeves that cover your knuckles.\" (Wait, you've used that one.)":
            $ c1_list = "sleeves"
            show ash smile
            "You get halfway through writing it before you realize 2019 you already claimed it. You underline it instead. Some things deserve to be thankful twice. Collarbones, for example. You've been told."
        "\"The last hour of being forty.\"":
            $ c1_list = "forty"
            show ash neutral
            "It looks more serious on the page than it felt in your head. You leave it. Forty was a good year. You got the tattoo. You got the painting. You got even more well-acquainted with back pain."

    show ash neutral

    "Forty-one in forty-six minutes. You check your phone out of habit. In Wisconsin it's still the morning of the seventeenth. The eastern hemisphere birthday messages will roll in tomorrow, the western the day after."
    
    "Your mom will message when her day gets around to remembering yours. She always does. She'll say \"Happy birthday from the past!\", just as you've sent your birthday wishes \"from the future\" all these years."

    "Your eyes drift, the way they do at this hour, to the wall above the sectional."

    "The almond blossoms. Three tall hanging scrolls that make one painting, white flowers on twisting branches against that impossible soft blue."
    
    "A friend painted it number by number over one long winter, before her contract ended and she flew home and became a name in a group chat. It's one of the most valuable things you own, in the way that matters."

    "You've stopped noticing it, mostly. That's what happens to beautiful things you see every day."

    "So you notice, now, when one of the blossoms moves."

    show ash surprised

    "You'd blame the candlelight, except it's a petal. A white painted petal detaches from a painted branch, turns over once in the painted air, and drifts down past the bottom edge of the scroll."

    "And out of it. Into your living room."

    "It lands on the arm of the sectional. You watch it sit there, three-dimensional and faintly luminous, for one full second of complete intellectual honesty in which you decide not to have had that much whisky."

    stop music fadeout 1.0
    $ whistle(0.4)

    "Then, from somewhere deep inside the painting, a whistle shrills. A police whistle. Long and outraged."

    st "{size=+10}STOP!{/size}"

    $ music("light hijinks")

    "The surface of the scrolls ripples like a pond somebody threw a rock into. Blue light floods the wall. A whole flurry of petals bursts out into the room, and behind them, head first, arms flung wide, comes a man."

    $ cg("cg home fall", whitefade)

    "He sails over the side table. He sails over the tissue box. He has curly dark hair, a black mask shoved up into it like a pair of sunglasses, and a shirt in bold black-and-white horizontal stripes, and a lumpy canvas sack flying along beside him like a loyal dog."
    
    "He is grinning. Of all the things he could be doing mid-air in a stranger's apartment, he is grinning."

    "He lands on your sectional with a whump that makes every throw pillow you own jump."

    $ light("fire")
    scene bg home night
    show ash surprised at lpos
    show rob surprised at gpos
    with quickdiss

    "The scrolls settle. The light dims. The petals drift down around him and lie on your grey upholstery, glowing faintly, like someone spilled a constellation."

    "He sits up. He's big. Broad through the shoulders, the stripes stretched across his chest like they were drawn for a smaller man. Stubble. A pale nick through one eyebrow. Warm brown eyes that go once around your living room, taking inventory, and land on you."

    show rob wry

    r "Evening. Hide me."

    "You'd like to point out that you are not the one who just fell out of a wall. Your mouth has other plans."

    menu:
        "Grab the whisky decanter by the neck. As a weapon.":
            $ c1_react = "decanter"
            show ash neutral
            "Cut crystal, heavy, full. You hold it up like a club."
            show rob laugh
            r "Is that a threat or an offer?"
            a "Depends how the next ten seconds go."
            r "Fair. That's very fair."
        "\"Who the {i}hell{/i} are you?\"":
            $ c1_react = "who"
            show ash neutral
            a "Who the {i}hell{/i} are you, and why are you in my couch?"
            show rob smile
            r "On. On your couch. In would be a different evening."
            a "That's not an answer."
            r "It's not, no. Sorry. Long night. Long thirty-six years, actually."
        "Hand him the whisky sour. He looks like he needs it more than you.":
            $ c1_react = "sour"
            $ sp()
            show ash wry
            "It is possibly the most Midwestern thing you have ever done. A strange man falls out of your art and your first instinct is hospitality."
            show rob surprised
            "He takes the glass in both hands like it might be a trick. He sniffs. Then he sips, and closes his eyes."
            show rob soft
            r "Oh, that's {i}good.{/i} What's the foam?"
            a "Egg white."
            r "You put an egg in a drink and made it a cloud. You were always like this."

    show rob neutral

    "Behind him, the painting gives an ominous ripple. Somewhere deep in the blue, the whistle sounds again, closer."

    $ whistle(0.65)

    "He doesn't look worried. He looks like a man who has heard that whistle every day of his life and has a few notes about its pitch."

    show rob wry

    r "Right. Quick version, because he's slow but he's thorough. You don't recognize me."

    a "Pretty sure I'd remember."

    r "You would think so."

    "He stands up, brushing petals off his trousers, and turns sideways, and holds out the sack at arm's length over his shoulder. He lifts one foot off the rug, bent behind him, like a man frozen mid-stride. A man running away."

    show rob run at runoff

    r "Help you at all? Bit of a profile. Back leg. Sack."

    show ash surprised

    "Something in the back of your skull rattles loose. Something waxy. Something that smells like crayon and the carpet of a Wisconsin classroom."

    "The sack. Lumpy, brown, with a drawn-on dollar sign. You know that dollar sign. You know it because it took you three tries to get the lines through the S right, and you were five, and you were very proud."

    $ music("nostalgia")
    $ cg("cg journal", longdiss)

    "Kindergarten. Mrs. Peterson's class. A primary journal, half blank space for drawing, half lined for writing."

    "Every single day, for what felt like forever and was probably a month, you drew the same thing. A cop chasing a robber. The robber running clean off the right side of the page so only his back leg and a bit of his profile showed, because you thought that was extremely clever."
    
    "The cop with a speech bubble: {i}Stop!{/i} And on the left, a red apple, with a green worm coming out of it, with a speech bubble of its own: {i}Go!{/i} You thought that was clever too."

    "And the lined half, every day, left completely blank. Until one day Mrs. Peterson leaned over your desk and asked, why don't you try writing something else?"

    "It had simply never occurred to you. That was all it took."

    $ light("fire")
    scene bg home night
    show ash surprised at lpos
    show rob smile at gpos
    with dissolve

    a "You're the robber."

    show rob laugh

    r "There she is."

    a "From my {i}journal.{/i} I was five. You're a crayon drawing."

    r "I {i}was{/i} a crayon drawing. Things grow up. You did."

    show rob neutral

    "He looks you up and down, warmly, frankly, and with no apology at all."

    show rob soft

    r "You got tall."

    show ash wry

    "You gesture at the general vicinity of his shoulders."

    a "You got... detailed."

    show rob wry

    r "Thirty-six years of running will do that. You gave me stripes, by the way, before I'd done a single thing. Prison stripes on page one. Presumptuous."

    a "You were carrying a sack with a dollar sign on it."

    r "Circumstantial."

    "The painting ripples again. This time a large white-gloved hand comes out of it and grips the edge of the scroll, and the whistle is very, very close."

    $ whistle(1.0)

    $ music("problem")

    show rob neutral
    show stop angry at stoppos behind rob, ash
    with quickdiss

    show ash surprised

    "A big man climbs out of your almond blossoms. Barrel-chested. A tall rounded helmet. Navy wool and a double row of brass buttons doing heroic work over a magnificent belly. The most opulent grey walrus moustache you have ever seen outside a cereal box, and above it a face gone red as a stop sign, which you suspect is the point."

    "He's the cop. Your cop. Round and blue and furious, exactly as drawn, plus about two hundred pounds of a third dimension."

    st "{i}Stop{/i} in the name of the Margin! Sir, you are in breach of section one, subsection four, of the Unfinished Works Act. Remain exactly where you are!"

    r "Constable. You remember the author."

    "The Constable's small pale eyes swivel to you. He takes in the cardigan, the slip, the bare legs, the decanter, the candles. A shade of extra red climbs his cheeks. He touches the brim of his helmet with great formality."

    show stop neutral at stoppos_l

    st "Madam. Apologies for the intrusion. It's late, and it's your home, and I'm very sorry for the petals."

    "His voice is gruff and English, a voice made for saying \"evening all\" in a tone that means \"none of that, now.\" You did not, at five, know any English policemen. You suppose he learned it somewhere."

    st "Step away from the suspect, if you please. The matter is nearly concluded."

    show ash neutral

    a "What matter?"

    st "Thirty-six years, madam, this fellow has been on the run off the edge of a page. There is a statute of limitations on an open case in the Margin, and his runs out at first light. At first light, the file closes."

    a "And then what?"

    "The Constable hesitates. For a second, under all the moustache, he looks less like a cop and more like a man who's been on his feet all night."

    st "Then he goes back in the drawer, madam. Closed, unresolved. One leg off the page, for good. It's the regulations."

    show rob neutral

    "You look at the robber. With his circumstantial sack. He doesn't look scared, exactly. He looks like a man who has decided a long time ago not to show it."

    a "And the sack?"

    r "Ah. Well. That's evidence."

    st "Stolen from the evidence locker of the Margin Constabulary not three hours ago."

    r "Allegedly."

    st "I watched you do it."

    r "From an angle."

    show rob wry

    r "It's your birthday present, Crayon. You can't open it before midnight."

    show ash flustered

    "Crayon. Nobody has ever called you that. It shouldn't land anywhere in particular, but it lands somewhere in particular."

    a "You stole me a birthday present from a police station?"

    r "I'm a thief. You made me one. It'd be rude not to."

    show stop angry at stoppos

    st "That's quite enough. Sir, you will come along quietly."

    show rob neutral

    "The robber turns to you, his back to the Constable, and his voice drops to something low and quick."

    r "Here's the thing he's not saying, because it's not in his regulations. A case can't close unresolved if the author resolves it. You're the only person in either world who can write the end of me."

    "He tips his head at the painting."

    r "But it has to be written in there, not out here. And it has to be before dawn."

    show ash surprised

    a "Write the end of you how?"

    show rob smile

    r "No idea. I was hoping you'd know. You're the writer."

    show ash smile

    "He holds out his hand. Big, warm-looking, a crayon-colored callus on the side of one finger that is neither how crayons nor calluses work."

    r "Come with me."

    "Behind him, the Constable puts the whistle to his lips."

    "You have a warm floor. You have a whisky sour and a thankful list due next week and, in forty minutes, a birthday that you were going to spend exactly like this. Cozy. Comfortable. Safe. You like your life."

    "But you've also spent a few years now existing in this valley more than living in it. And there's a man you drew when you were five standing in your living room asking you to come and find out how he ends."

    menu:
        "Take his hand.":
            $ c1_go = "hand"
            $ sp()
            show ash smile
            "You don't let yourself think about it. You put your hand in his."
            show rob soft
            "His fingers close around yours, warm and certain, and something on his face goes very bright and very young for a second, like a kid who wasn't sure he'd get picked for dodgeball."
        "Grab the whisky sour, {i}then{/i} take his hand.":
            $ c1_go = "sour"
            show ash wry
            "You are not leaving a whisky sour with real egg white on a coffee table for a fictional policeman. You knock it back in one long swallow, foam and all, set down the empty glass, and take his hand."
            show rob laugh
            r "Priorities. God, I missed you."
            a "You've never met me."
            r "I've met you every day for thirty-six years. You just weren't looking at the margins."
        "Turn to the Constable. \"Sir, this is my apartment.\"":
            $ c1_go = "stop"
            show ash neutral
            a "Sir. Constable. With respect, this is my apartment, and it's nearly my birthday, and I'm not dressed for an arrest."
            show stop neutral at stoppos_l
            st "Madam, I quite understand, and I can only..."
            "While he's busy being courteous, you take the robber's hand."
            show rob laugh
            r "Oh, I {i}like{/i} you."

    show stop angry at stoppos
    $ whistle(1.0, 2)
    st "{size=+10}STOP!{/size}"

    show rob laugh

    r "{size=+6}Go!{/size}"

    "Hand in his, he runs straight at your wall. He takes you with him. You have exactly enough time to think {i}how will I explain this to my landlord{/i} before the almond blossoms open like a curtain of blue water and close over your head."

    stop music fadeout 1.5
    scene black with whitefade

    "You brace for water. What you get is cool air that smells like linseed oil and old paper, and the sound of a breeze through leaves. That rising, falling hush you once spent ten minutes trying to name before settling on {i}susurration{/i} with enormous satisfaction."

    "Then there's a floor under your socks again."

    $ light("dim")
    scene bg gallery night with slowfade
    $ music("music box mystery")

    "The floor is honey-colored parquet, polished to a mirror, and it runs away from you down the longest room you have ever stood in."

    "Arches of white marble with carved tracery, one after another after another. Teal silk on the walls. Balconies of black ironwork overhead, and above those a ceiling of stained glass with real stars behind it."
    
    "And on every wall, floor to ceiling, in heavy gilded frames of every size, paintings."

    "Except they aren't paintings. They're windows. Windows to stories. A moonlit sea, its waves actually moving. A meadow of wildflowers bending under a wind you can't feel. A snowy village with smoke going up from chimneys. A garden of trees in sweet-shop colors."
    
    "Each one spills its own light onto the floor, so you're standing in a puddle of moonlight and a stripe of meadow-gold at the same time."

    show ash surprised at lpos
    show rob smile at gpos
    with dissolve

    a "Oh."

    "That's all. You had a whole career's worth of vocabulary a minute ago. You got a perfect 170 on the verbal section of the GRE. {i}Oh.{/i}"

    r "Welcome to the Gallery. Your other book. The one about paintings you end up inside, until a painting of home brings you back."

    show ash neutral

    a "I wrote that when I was seven."

    r "You wrote it very confidently. There was a binding machine involved. Little plastic spiral. The Margin takes that sort of thing seriously."

    a "My teacher took it seriously. That meant a lot. ...Wait, the Margin?"

    show rob wry

    r "Everything you ever started and didn't finish. The things you did, too. Everything you ever loved enough to notice and didn't write down properly. It all comes here and waits. Your first robber. Your bush that grows whatever you wish for."

    show rob laugh

    r "Candy and money, as I recall. Strong opening. Clear priorities."

    show ash wry

    a "I was five. Candy and money {i}are{/i} the priorities."

    r "Still are, if we're honest."

    "Behind you, the painting you came through is your own living room. You can see your sectional, your candles, the glass on the coffee table, all from the wrong side, like looking into a dollhouse. The fairy lights look like a wall of tiny stars."

    "A big shadow moves across it. The painted almond blossoms on the painted wall begin to ripple."

    show rob neutral

    show ash neutral

    r "He'll come through any second. He always does. Bless him, it's the only thing he knows how to do."

    a "Where do we go?"

    r "Away. Then somewhere. Then we'll see. Also, before anything else, a small administrative problem."

    show ash wry

    a "Only one?"

    r "You never named me."

    show ash surprised

    "You open your mouth. Close it."

    r "The Constable calls me the Suspect. The worm calls me {i}mate{/i}. I've been the Robber for thirty-six years, and it's a fine job title, but it's not the kind of thing you'd want shouted at you across a nice restaurant."

    "He spreads his hands."

    r "Author's privilege."

    "There's no time. There's a whistle. There's a ripple on the wall behind you and a very good-looking man in front of you waiting, with what is clearly a lot of hope and not much practice at it, to be called something."

    menu:
        "\"Rob.\" Obviously. You were five, not a poet.":
            $ rob_name = "Rob"
            show ash wry
            show rob laugh
            r "Rob. A robber called Rob."
            a "It's a classic."
            r "It's {i}on the nose.{/i}"
            a "So's the dollar sign."
            show rob soft
            r "...Rob. Yeah. All right. I'll take Rob."
        "\"Robin.\" Steals from the rich. Has a nice ring.":
            $ rob_name = "Robin"
            show ash smile
            show rob smile
            r "Robin. Like the outlaw."
            a "Like the bird, too. You came flying in with the petals."
            show rob soft
            r "Robin. I can live with that. I'd like to live with that, actually, that's the whole point."
        "\"Dollar.\" Because of the sack. And because it's funny.":
            $ rob_name = "Dollar"
            $ sp()
            show ash wry
            show rob laugh
            r "{i}Dollar.{/i}"
            a "Your sack. It's the only identifying feature I gave you."
            r "You have named me after my {i}sack.{/i}"
            a "You have an iconic sack."
            show rob soft
            r "...God help me, I love it. Dollar. Surname Sack. Nobody will ever forget it."

    $ whistle(0.7)

    show worm neutral at wormpos_l with quickdiss

    "Something at your feet says, with tremendous enthusiasm:"

    w "{size=+8}GO!{/size}"

    "You look down. On the parquet sits a shiny red apple. Out of a neat hole in its side leans a bright green worm with enormous dark eyes, tiny arms, and the face of someone who has had six espressos and loves every one of them."

    a "Oh my God. The worm."

    w "GO! Hi! GO!"

    r "He says hello. He also says go. He mostly says go."

    a "Are we not gonna talk about the arms?"

    w "He's coming! Big boots! GO GO GO!"

    "The almond blossoms behind you bulge outward like a sail. A white glove appears."

    show rob smile

    r "Can't argue with the worm."

    "[rob_name] scoops up the apple and tucks it into the crook of his arm like a football, worm and all, and takes your hand again. You run."

    hide worm
    hide rob
    hide ash
    with fadeout

    "Down the long hall, through puddles of moonlight and meadow-gold, your socks sliding on the parquet. You remember a line from one of your lists about sliding across a good smooth floor, Risky Business style."
    
    "You do it now. On purpose. And then a little not-on-purpose because that's how momentum works. [rob_name] laughs out loud and does it too, sack swinging, and behind you a gruff voice cries {i}Stop!{/i} and you don't."

    "At the far end of the hall there's a painting of a lamplit street, cobbles shining with rain, red and gold leaves blowing. He doesn't slow down. Neither do you."

    stop music fadeout 2.0
    scene black with whitefade

    ## Interlude: the Constable
    call pov_card("The Constable")
    $ music("melancholy")
    $ light("dim")
    scene bg gallery night with longdiss
    show stop neutral at cpos with dissolve

    "The Constable climbs down from the almond-blossom frame with the care of a man whose knees don't pull their share of a group project."

    "The Gallery is empty. It always is, by the time he arrives. A trail of white petals runs off down the parquet toward the street painting at the far end, and two long smears where somebody's socks have slid."

    "He doesn't run after them. Not yet. He's learned, over thirty-six years, that he needn't. The Margin is only so big, and the Suspect always, always runs in a straight line."

    show stop tired with dissolve

    "He takes off his helmet. He's allowed, when nobody's looking. His hair underneath is thin and grey and pressed flat, and his scalp is damp, and the cool air of the Gallery feels like a mother's hand."

    "From inside his tunic he takes the warrant. One sheet, folded in four, soft as cloth from handling. {i}Closed, unresolved, at first light.{/i}"
    
    "He's read it so many times he could recite it. He reads it again anyway, because that's what you do with orders. You check them."

    "He thinks about the author. Taller than he'd pictured. A tired, kind face, and a cardigan, and a drink with a cloud on it, and a living room so warm the floor gave off heat through his boots."
    
    "He'd stood in that room for one minute and felt his feet stop aching for the first time since 1990."

    "He'd said {i}stop{/i} to her, and she hadn't. He'd been saying it to her for a very long time, in one voice or another. Be sensible. Stay where it's warm. Don't run off the edge of the page; you don't know what's there."

    "He'd only ever meant it kindly."

    "The Constable puts his helmet back on, straightens his tunic over his belly, and tucks the warrant away. Somewhere outside the Gallery the first snow of the season is thinking about falling. He can feel it in his knees."

    "First light. He has until first light. And then, for the first time in thirty-six years, the chase will be over."

    "He isn't sure, standing alone in the long bright hall, why that doesn't feel like winning."

    stop music fadeout 2.0
    scene black with blackfade
    return
