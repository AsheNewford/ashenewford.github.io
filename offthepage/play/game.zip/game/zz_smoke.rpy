## Headless crash check. Does nothing unless the BDAY_SMOKE environment variable is set.
## Run: BDAY_SMOKE=1 SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy sh renpy.sh Birthday run
init python:
    import os
    SMOKE = bool(os.environ.get("BDAY_SMOKE"))
    if SMOKE:
        config.auto_choice_delay = 0.02
        config.allow_skipping = True
        def _smoke_tick():
            config.skipping = "fast"
        config.periodic_callbacks.append(_smoke_tick)
        def _shot(name):
            d = os.path.join(config.basedir, "_art_raw", "shots")
            if not os.path.isdir(d):
                os.makedirs(d)
            renpy.screenshot(os.path.join(d, name + ".png"))

label splashscreen:
    if SMOKE:
        $ _preferences.skip_unseen = True
        ## open every menu screen once, so a broken screen fails here and not on the player
        python:
            for _s in ("preferences", "save", "load", "about", "help", "history", "main_menu"):
                renpy.show_screen(_s)
                renpy.pause(0.05)
                renpy.hide_screen(_s)
                renpy.pause(0.05)
            print("SMOKE: menu screens ok")
            ## Extras: the gallery (with everything unlocked) and every tab of the scene maker.
            for _n, _t in gallery_items():
                persistent.cg_seen.add(_n)
            renpy.show_screen("kindling_gallery"); renpy.pause(0.05)
            renpy.show_screen("gallery_view", name=gallery_items()[0][0], tag=gallery_items()[0][1]); renpy.pause(0.05)
            renpy.hide_screen("gallery_view"); renpy.hide_screen("kindling_gallery"); renpy.pause(0.05)
            persistent.cg_seen = set()
            sm_open(); renpy.pause(0.05)
            print("SMOKE: before show-all, %d places and %d people unlocked" % (len(sm.places()), len(sm.people())))
            sm.reveal_all(); renpy.show_screen("scene_maker"); renpy.pause(0.1)
            renpy.show_screen("kindling_credits"); renpy.pause(0.05); renpy.hide_screen("kindling_credits")
            title_music(); renpy.pause(0.05)
            for _t in sm.tracks:
                assert track_credit(_t), _t
            for _fam in sorted(sm.bgs):
                sm.fam = _fam
                for _i in range(len(sm.bgs[_fam])):
                    sm.var = _i; renpy.pause(0.02)
            for _c in sorted(sm.chars):
                sm.slots = []
                sm.add_char(_c)
                for _o in sorted(sm.chars[_c]):
                    sm.set_outfit(0, _o)
                    for _e in sm.chars[_c][_o]:
                        sm.slots[0]["expr"] = _e
                    renpy.pause(0.02)
            for _tab in ("bg", "chars", "music"):
                sm.tab = _tab; renpy.pause(0.05)
            sm.light = "night"; sm.slots[0]["flip"] = True; sm.slots[0]["depth"] = 2; renpy.pause(0.05)
            renpy.hide_screen("scene_maker"); renpy.pause(0.05)
            print("SMOKE: extras ok, %d places, %d characters, %d tracks" % (len(sm.bgs), len(sm.chars), len(sm.tracks)))
        jump start
    return

