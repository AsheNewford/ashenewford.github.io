## Chapter Three: The Lined Half

default c3_water = None
default c3_pace = None
default c3_stop = None
default c3_end = None
default c3_list = None
default c3_book = None
default c3_rating = "r"

label chapter_03:
    call chapter_card("Chapter Three", "The Lined Half")

    $ ash_outfit = "dress"
    $ rob_outfit = "coat"
    $ light("night")
    scene bg street snow with slowfade
    $ music("serious")

    "You stand in the dark of the arch with your cheek on his chest and listen to the Constable huff."

    "He doesn't come in. There's no need to. There's one way out of the doorway, and he's standing in it, a broad navy silhouette against the snow and the lamplight, patient as a post box."

    st "Come out when you're ready, sir. I'm in no hurry. First light's in a few hours, and I've got nowhere else to be. I've never had anywhere else to be."

    "[rob_name]'s arms tighten around you. You feel him take a breath to say something brave and stupid."

    "Then his coat pocket says:"

    w "{size=+8}GO!{/size}"

    "The apple shoots out of the greatcoat, like a cork out of a bottle. It bounces once on the snowy cobbles, rolls straight between the Constable's boots, and the worm leans out of it as it passes and yells {i}GO GO GO{/i} at the top of his tiny lungs."

    "You'll think about worm lungs later, maybe after you get around to the arms."

    "The Constable, who has been chasing a robber for thirty-six years and has excellent reflexes for exactly one kind of thing, turns and lunges after the apple."

    show ash wry at lpos
    show rob laugh at gpos
    with quickdiss

    r "Oh, I {i}love{/i} that worm."

    "You run."

    $ music("problem")

    hide rob
    hide ash
    with fadeout

    "Down the lane, slipping on the new snow, your skirt in one fist and his hand in the other, out from under the trees and onto the little stone bridge at the bottom of the hill."
    
    "You don't know where you're going. Neither does he; you can tell by the way he keeps looking both ways at once."

    "Halfway across, [rob_name] stops dead and you skid to a smashing halt into very firm shoulders."

    show ash surprised at lpos
    show rob neutral at gpos
    with quickdiss

    "The Constable is coming toward you, puffing, the apple tucked under one arm like a rugby ball and the worm yelling indignantly in his white glove."

    w "Guh! Pff! Thmp-Mrrf. Guh! Guh!"

    "He's at the far end of the bridge."

    "You look back. The Constable is {i}also{/i} coming up behind you."

    a "How is he on {i}both ends?{/i}"

    show rob wry

    r "It's his whole job. You wrote him to be everywhere I was going. Can't fault the man's work ethic."

    "The bridge is narrow. The river underneath is black and fast and full of floating leaves. The snow is coming down thicker now, lazy and lovely and absolutely no help at all."

    show rob neutral

    r "Crayon. If you've got anything, now's the time."

    "You've got nothing. You're in velvet and wet socks on a bridge with a man you drew in kindergarten, and the only thing in your head is the sound of Mrs. Peterson's voice, leaning over your desk, smelling of coffee and hand lotion."

    "{i}Why don't you try writing something else?{/i}"

    "And then the page after the robber. The very first one you ever wrote on. You filled the lined half and went over to the back and filled that too. You don't remember all of it."
    
    "You remember clouds. And a unicorn, except it lived in the clouds, so logically it must have been..."

    $ music("happy hope")

    show ash smile

    "{i}The rule of the wishing bush. Out loud. It's important. Most people are terrible at it.{/i}"

    "You've been terrible at it for years."

    "You put your head back and say, to the snow and the sky and the Constable and the river:"

    a "Once there was a pegasus who lived on top of the clouds. And whenever anybody needed to go somewhere far away, very fast, she came down to get them."

    "The snow stops falling."

    "Not slowly. All at once. Every flake in the air hangs where it is, glittering in the lamplight, and the Constables at both ends of the bridge stop with their boots in the air, and a wind comes down out of the sky that smells like starlight and clean cold heights."

    "Something white and enormous drops through the clouds."

    show rob surprised

    r "Oh, you're {i}good.{/i}"

    "She lands on the bridge in a gust that blows the hanging snow out sideways like a curtain. Pure white, taller than any horse you've ever stood next to, with a silver mane and eyes like a clear night."
    
    "Her wings are so big that when she folds them they still reach the water on either side, but she doesn't seem to mind. She looks at you the way a teacher looks at a student who finally got it."

    "You were five. You wrote a pegasus. She waited thirty-five years."

    "[rob_name] gives you a leg up. You've never ridden a horse bareback in your life and you do it now in a velvet dress with pockets, sideways."
    
    "He swings up behind you, his arm comes around your waist, and from the far end of the bridge a gruff voice shouts {i}stop{/i} and from the near end, the same voice, slightly out of breath, shouts it again."

    "The worm, somewhere in a white glove, shouts {i}GO{/i}. The pegasus agrees with the worm."

    stop music fadeout 0.5
    $ music("let's enjoy")
    $ cg("cg sky pegasus", whitefade)

    "Up. Through the snow, through the clouds, and out the top of them into a sky so full of stars there's scarcely room for the dark."

    "The wind takes your breath and your hair and all your sense. Below, the clouds roll away in every direction like a moonlit sea, and through the gaps you can see the lamplit roofs and spires of the Margin falling away beneath you, small as a toy set, the whole lane still glittering with snow and smile waves."

    "There's a full moon the size of a dinner plate. There's a man behind you with his arm around your waist and his coat billowing out behind you both like a flag."

    "You throw your arms out wide. You don't decide to. They just go."

    "You laugh. Not a polite laugh. A whoop, a yell, a child-on-a-hill laugh, the kind you used to do running down a slope with the momentum carrying you and the belated wonder of whether you'd be able to stop. You can't stop. You don't want to."

    "Behind you, his laugh, against your ear. His arm tightens. He's not holding on to the pegasus. He's holding on to you."

    r "Where are we going?"

    a "I don't know! You tell me!"

    r "Not me. It's your pegasus. She takes you where you need to go."

    "The pegasus banks, long and slow, out over the edge of the clouds."
    
    "Below the sea of clouds the Margin ends, and past the end of it is an actual sea."

    stop music fadeout 2.0
    scene black with dissolve
    $ music("peaceful")
    $ light("moon")
    scene bg beach night with longdiss

    "She sets you down on black sand."

    "Black sand. Fine and glittering under the moon, like someone ground up the night sky and spread it on a beach."
    
    "Dark lava rock, porous and twisted, framing a small crescent cove. Behind you a cliff of basalt rising in tall hexagonal columns like the pipes of an organ, crowned with wind-bent pines and silver grass that hisses in the breeze."

    "And the water. Clear and turquoise even at night, lit from inside, it seems, breaking in bright white foam on the black sand. A path of moonlight running straight out to the horizon."

    "And far out on that horizon, a storm. Towering clouds, with violet lightning flickering inside them, too far away to hear. Just the light. Opening and closing, like something magnificent breathing."

    show ash surprised at lpos
    show rob smile at gpos
    with dissolve

    "The pegasus folds her great wings, touches her nose once to your shoulder, and goes up into the night without a sound."

    a "I know this place."

    r "Do you?"

    show ash neutral

    a "I've seen it in pictures. Black sand. Basalt columns. Volcanic. It's an hour's flight from my house. It's on a list I've had for twelve years. Not the thankful one. The other one."

    show rob soft

    r "The one you never post."

    a "Beaches are my favorite thing on earth. I've flown to Thailand for a beach. Vietnam. The Philippines. And I've never once gone to the one that's practically down the road."

    r "Why?"

    "You think about it. You've thought about it before."

    a "Because it's always there. It's the easiest one. It's the one I could do any weekend. So I never do it on any weekend."

    show rob wry

    r "Huh. You know who else you could have done any weekend, and never did?"

    show ash laugh

    a "Oh, shut up. I've done about a hundred versions of you. You were just too busy running off the page to read them."

    "He laughs. You laugh. The waves come in and go out and come in again. The storm far out at sea breathes violet and dark, violet and dark."

    "You take off your wet socks. The black sand is cool and soft and squeaks a little under your bare feet."

    show ash smile

    "And you walk down to the water, and keep walking."

    hide ash with fadeout

    "It's cold for a second, at your ankles, and then, impossibly, it isn't. The top layer is warm. Sun-warm, bath-warm, like the whole sea has been sitting in the afternoon all day and saved some for you."
    
    "You wade in to your knees, your thighs, your hips, and the velvet goes dark and heavy and floats out around you, and the pockets fill up with sea."

    "You turn around. He's standing at the edge of the water with his greatcoat over his arm, watching you, and the look on his face would justify an entire book and a sequel."

    menu:
        "\"Are you coming in, or do I have to draw you in?\"":
            $ c3_water = "dare"
            $ sp()
            "He drops the coat on the sand like it's offended him."
        "Hold out your hand.":
            $ c3_water = "hand"
            "You don't say anything. You just hold out your hand, palm up, the water to your waist and the moon behind you."
            "He drops the coat on the sand."
        "Splash him. Right in the face.":
            $ c3_water = "splash"
            $ sp()
            "You scoop up a double handful of warm sea and fling it at him. It hits him full in the face. He stands there dripping, blinking, outraged."
            "Then he drops the coat on the sand, and you know you're in trouble."

    "He pulls the white shirt over his head and throws it on top of the coat."
    
    "In the moonlight he is entirely unreasonable. Broad shoulders and a broad chest dusted with dark hair, the muscle of a man who has run without stopping for thirty-six years, his stomach cut into neat hard sections like somebody drew it with a ruler. You suspect, now, that someone did. You suspect it wasn't you."

    "Last of all, he reaches up and pulls the black mask out of his curls. He holds it for a moment. He's had it since the first page."

    $ rob_outfit = "bare"
    show rob neutral at gpos with dissolve

    "He drops it on the coat."

    r "I don't need to hide from you."

    hide rob with fadeout

    "Then he walks into the sea."

    "Waist-deep, an arm's length from you, he stops. The water streams off his shoulders. He looks at you across that last little stretch of sea, and you can see him decide to ask, the way he always does, instead of assuming."

    r "Before I come any closer, Crayon. What kind of story is this?"

    menu:
        "PG, sweet.":
            $ c3_rating = "pg"
            jump c3_pg
        "R, fully R.":
            $ c3_rating = "r"

    $ music("dramatic entice")
    $ cg("cg beach surf", longdiss)

    "He comes through the water like it isn't there, and he takes your face in both hands, and he kisses you."

    "The snow kiss was a question. This one is the answer, and it's loud."

    "A wave breaks over you both, white and roaring, and neither of you lets go. Salt in your mouth. Salt in his. His hands slide back into your wet hair and fist there, gently, tilting your head where he wants it."
    
    "You let him, and you spread your hands on his chest because you've been wanting to since the garden, and it's exactly what you thought it would be: warm, solid, his heart going hard under your palm like it's trying to get out and get into you."

    "The velvet clings to you, and you're aware of every inch of it. So is he. His hand slides down your back and finds the zip, and stops, and his mouth leaves yours just long enough to ask."

    r "Yes?"

    a "{i}Yes.{/i}"

    "The zip goes down. The water takes the dress off your shoulders and he takes it the rest of the way, slow. The sea is warm on your bare skin, and then he is, his whole chest against yours, skin to skin, and you both make the same sound at the same time, from different registers."

    "Far out at sea, the storm opens violet. Some scenery is pretty. Some scenery makes sweet, sweet love. Thunderstorms and crashing waves absolutely fuck. You wrote that. Turns out it was {i}research.{/i}"

    "He laughs into your neck, because you said that last part out loud."

    r "I know. I read it. I've been thinking about it for a year."

    "He lifts you. Just like that. His hands under your thighs, and your legs go around his waist without consulting you."
    
    "He carries you up out of the water with the waves pushing at his back, the dress forgotten somewhere in the foam, your arms around his neck, laughing and kissing and dripping, all the way up the black sand to where he dropped the coat."

    $ music("sensual")
    $ cg("cg beach coat", longdiss)

    "He goes down on his back on the spread greatcoat and pulls you with him, and you end up above him, your knees on the wool on either side of his hips, your hands braced on his chest, your wet hair dripping onto his skin."

    "He looks up at you. The moon is behind you, so the light is on him: the wet curls tangled on the charcoal wool, the drops of seawater on his chest catching silver, the flush on his cheekbones, his lips parted. His eyes have gone very dark."
    
    "He looks at you like he's been looking at you through glass for years and someone has finally opened the window."

    r "Look at you."

    "His voice is gone rough. His hands are at your waist, not pulling, just holding, his thumbs moving in small slow circles on your hipbones."

    r "I've imagined you a thousand ways, Crayon. I still didn't get close."

    "You can feel him under you. Hard, and hot, through the wet cloth of his trousers, pressing right where you're aching for it. You roll your hips once, deliberately, just to see what happens to his face."

    "What happens to his face is worth a whole trilogy."

    r "{i}Fuck.{/i}"

    "He says it like a prayer, as blessed as it is profane. His fingers dig into your hips. His head goes back against the coat."

    "You get his belt open. Your fingers aren't steady and the leather's wet and it takes two tries. He laughs, breathless, and helps, and between you the trousers go somewhere down the beach."
    
    "And then there's nothing between you but sea air and the light of a storm. You take him in your hand and he makes a sound you'll be thinking about for the rest of your life."

    "He's thick and hot and heavy in your palm, and when you stroke him, slow, base to tip, his whole body arches up off the coat."

    r "Wait. Wait, wait. Inside pocket. Left side."

    a "You have a condom in your coat?"

    r "I'm a thief. I plan ahead."

    a "You stole a condom."

    r "I stole {i}three.{/i} I'm an optimist."

    "You find them. You open one with your teeth. You roll it down onto him slowly, so slowly, watching his face the whole time, and his jaw goes tight. His hands make fists in the wool, and you discover you have a cruel streak you'd like to explore further at some point."

    "Then you rise up on your knees, and take him in your hand, and line him up, and look down at him."

    menu:
        "Slow. Make it last.":
            $ c3_pace = "slow"
            "You sink down on him a fraction of an inch at a time."
            "God. The stretch of him. The heat. You go so slowly you can feel every single part of him opening you, filling you, and he holds absolutely still for it, shaking with the effort."
            "His eyes are locked on yours, until you're seated all the way down on him and you both have to stop and just breathe."
        "Now. Right now.":
            $ c3_pace = "now"
            "You've waited forty-one years for a lot of things. Not this. You sink down on him in one long, smooth, unbearable slide."
            "The breath goes out of both of you at once. He's so deep. He's everywhere. You freeze there, full, stretched, your nails in his chest, and he's swearing softly and steadily up at the sky in a voice you wrote and don't remember writing."

    "Then you move."

    "You ride him slow at first, the way the sea moves, coming in and going out, rocking your hips and finding the angle. And when you find it you both know it, because you make a noise and he says your name."

    r "[mc]."

    "Not Crayon. Your name. He's never said your name before, you realize. You had no idea how badly you wanted to hear it in his mouth until it was there."

    "His hands come up from your waist to your breasts, warm and wet, his thumbs dragging over your nipples, and the jolt of it goes straight down to where he's moving inside you."
    
    "You lean into his hands. You go faster. The waves keep breaking behind you. You can hear them, crash and hiss and crash, and you find yourself matching them without meaning to, each wave a stroke, each stroke a wave."

    "He's watching you. The whole time. Your face, your breasts, the place where he disappears inside you, back to your face. Like he's reading. Like he doesn't want to skip a single line."

    r "You're the most beautiful thing in the Margin. You're the most beautiful thing {i}anywhere.{/i}"

    "You can't answer. You're too busy. Pressure is building low and tight and sweet, the kind that makes your thighs start to tremble. You plant your hands on his chest and grind down on him, harder, chasing it, and he gets it immediately."
    
    "He plants his heels in the sand and drives up into you, meeting every move, and the angle changes, and it's {i}right there.{/i}"

    "Out at sea the storm lights up violet from end to end."

    "One of his hands slides down your stomach. His thumb finds your clit, swollen and desperate, and circles it, exactly as hard as you need, exactly as slowly, while he moves inside you."
    
    "You hear yourself say {i}oh, oh, oh, don't stop, don't stop.{/i}"

    "It's the funniest thing you could possibly say to him and neither of you laughs. He doesn't stop. He has never in his life been less inclined to stop, and he's had a long life of not-stopping."

    "You come apart on top of him."

    "It rolls through you like the surf, from where he's buried in you outward, curling your toes in the sand, arching your back, tearing a sound out of you that the storm would be proud of."
    
    "You clench around him, again and again, and he groans like you're killing him and keeps his thumb right there and keeps moving, drawing it out, wringing every last wave out of you until you're shaking and gasping and folding down onto his chest."

    "He catches you. He wraps both arms around you and holds you against him, and his hips are still moving under you, short and rough now, uneven, his breath ragged in your ear."

    r "[mc]. I'm... God. I'm..."

    a "Yes. {i}Yes.{/i} Come for me."

    "He does. He pushes up into you one last time, as deep as he can go, and holds there, and shudders all the way through, his face buried in your wet hair, your name coming out of him over and over like the only word he's ever been sure of."

label c3_after:

    $ music("heart full")

    $ cg("cg beach sleep", longdiss)

    "Afterward, nobody moves for a long time."

    "You lie on top of him on the coat with your cheek on his chest. His heart slows down under your ear in stages. The storm out at sea goes violet, dark, violet, dark. The surf comes in and goes out."
    
    "He's tracing slow lines up and down your back with one finger, like he's drawing you."

    if c3_rating == "pg":
        r "Your dress is soaked."

        a "My dress is soaked."

        r "The pockets are full of sea."

        a "Best pockets I've ever owned."
    else:
        r "Your dress is in the ocean."

        a "My dress is in the ocean."

        r "It had pockets."

        a "It had {i}such{/i} pockets."

    r "You wrote in another coat."

    a "I did, yes. Suspension of disbelief only goes so far. Jeju is subtropical. It's chilly."
    
    "You feel him laughing, under your cheek. He reaches over without looking and drags the far side of his coat over you both, because the subtropical sea air is getting cool."
    
    "He tucks it around your shoulders. There is a lot of coat."

    r "It's past midnight, by the way. Your side."

    "You lift your head."

    r "I keep an eye on your clock. Professional habit."

    "He pushes the wet hair off your forehead with two fingers, very carefully."

    r "Happy birthday, Crayon."

    if c3_rating == "pg":
        "Forty-one. You turned forty-one lying on a beach on the edge of the world, wrapped in the coat of a man you drew in crayon at five. You've had worse birthdays. Statistically, you've had forty worse birthdays."
    else:
        "Forty-one. You turned forty-one while you were naked on a beach on the edge of the world, on top of a man you drew in crayon at five. You've had worse birthdays. Statistically, you've had forty worse birthdays."

    "You put your head back down. You don't say anything for a while."

    "Then, into his chest, very quietly:"

    a "Thank you."

    "He doesn't ask what for. His arm tightens around you, and stays."

    stop music fadeout 3.0
    scene black with blackfade

    $ music("tentative tender")
    $ cg("cg beach sunrise", longdiss)

    "You must sleep. You wake to warmth on your face."

    "Dawn. The sky has gone gold and peach and rose and soft lavender, and the clouds where the storm was are lit from beneath like lanterns. The sea glitters turquoise. The sun is just lifting itself out of the water, and it's shining straight on you."

    "You're lying on his chest in the coat on the black sand, and you do the thing you always do. You don't even think about it."
    
    "You tip your face up toward the sun, and you close your eyes, and you let it lie warm on your cheeks."

    "Your mother does it. Your grandmother did it. Your great-grandmother, too. You've wondered how many generations back it goes, women standing in a field or a doorway or a parking lot with their faces up and their eyes shut, soaking it in."

    "Something makes you open one eye."

    $ cg("cg beach rob", dissolve)

    "Under you, [rob_name] has his face tipped up to the sun. His eyes are closed. There's a small, peaceful smile on his mouth."

    "He's doing it too."

    a "Where did you learn that?"

    "He doesn't open his eyes."

    r "Watching you. Every sunny morning for years. Through the almond blossoms."

    "A small shrug, under your cheek."

    r "It looked like the best thing in the world. Turns out it is."

    $ cg("cg beach both", dissolve)

    "You close your eyes again, and turn your face back up to the sun, and you add one more name, quietly, to the list of people who do this. Your mother. Your grandmother. Your great-grandmother. A robber."

    "He stole it. It seems an entirely defensible thing to steal."

    "You stay like that until the sun is all the way out of the sea."

    $ ash_outfit = "dress"
    $ rob_outfit = "bare"
    $ light("dawn")
    scene bg beach dawn with dissolve
    $ music("serious")

    if c3_rating == "pg":
        "You wring the sea out of your pockets. Your dress is sodden and sandy and you don't care. He finds his shirt and doesn't put it on. You decide not to mention it."
    else:
        "You find your dress at the tideline, sodden and sandy, and wring out the pockets, and put it back on anyway."
        "He finds his trousers. He doesn't find his shirt. You decide not to mention that he isn't looking very hard."

    show ash smile at lpos
    show rob neutral at gpos
    with dissolve

    "And then, down the beach, crunching on the black sand, comes a navy-blue silhouette."

    $ whistle(0.45)

    show rob neutral
    show stop angry at stoppos behind rob, ash
    with quickdiss

    "The Constable."

    "He has sand in his boots. He has seaweed on one shoulder. His helmet is crooked and his moustache is wilting and he has the apple in one fist, worm and all, and the worm looks thrilled to be anywhere."

    st "First... light."

    "He has to stop and get his breath."

    st "First light, sir. The case... is closed. I'll thank you to... come along."

    "[rob_name] doesn't run."

    "You feel him not run. His whole body, which has done exactly one thing for thirty-six years, decides to do a different one."
    
    "He stands his ground on the black sand with the sun on his back and the sack at his feet, and waits."

    "Which means it's your turn."

    show ash neutral

    menu:
        "Argue the law. You've read a lot of fine print in your life.":
            $ c3_stop = "law"
            a "Constable. You said a case closes unresolved at first light. Section one, subsection four."
            show stop neutral at stoppos_l
            st "That's correct, madam."
            a "Unresolved. But the author's standing right here. On the beach. Willing to resolve it. So it's not unresolved. It's {i}pending.{/i}"
            a "You can't close a pending case. That's not stopping a thing. That's interrupting it."
            "The Constable opens his mouth. He shuts it. His moustache moves through several stages of thought."
            st "...That's a very good point, madam."
            a "I've been a teacher for a long time. I've heard every excuse there is. Including my own."
        "Ask him to sit down. Just sit.":
            $ c3_stop = "sit"
            $ sp()
            a "Constable. Would you like to sit down?"
            show stop neutral at stoppos_l
            "He stares at you as if you've suggested he take up ballet."
            a "The sand's warm. The sun's on it. I promise you it's the warmest patch on the whole beach. I'm an expert. I have floor heating."
            "His knees, which are slackers, vote before he does."
        "Ask him what {i}he{/i} wants.":
            $ c3_stop = "want"
            $ sp()
            a "What do you want, Constable?"
            show stop neutral at stoppos_l
            st "I want the suspect in custody, madam."
            a "No. What do {i}you{/i} want? When this is over. When he's back in the drawer. What do you do then?"
            "He opens his mouth. Nothing comes out of it. Under the moustache, something in his face starts to give."

    show stop tired with dissolve

    "The Constable reaches up, very slowly, and takes off his helmet."

    "His hair underneath is thin and grey and flattened, and his scalp is damp, and he holds the helmet against his belly like a man at a funeral. Or a man at the end of a very long shift."

    st "I don't know, madam. That's the truth of it. I've never not been chasing him. If I catch him, what am I for?"

    "He looks at the robber. He looks at the sea. He looks, finally, at you."

    st "You wrote me to say stop. That's all I've ever said. Be careful. Be sensible. Stay where it's warm. Don't run off the edge of the page, you don't know what's there."

    "His voice goes rough."

    st "I only ever meant it kindly."

    show ash soft

    a "I know you did."

    "And you do. You've heard him all your life. He's the voice that kept you in the warm room with the good floor and the golden handcuffs and the list of little things, the voice that said {i}why go to Jeju, it's always there.{/i}"
    
    "He kept you safe. He kept you comfortable. He kept you so comfortable that you forgot there was any running left in you."

    "But he's not wrong. Not entirely. Somebody had to say stop. There's a lot to be said for a warm room and a good floor."

    show worm neutral at wormpos_mid_l behind stop with quickdiss

    w "GO!"

    "The worm. From the Constable's glove. The other half of the page."

    a "You were both right. That's the problem. Stop and go. I needed both of you. I've just been listening to one of you a little too long."

    "You walk over to the Constable. You put your hand on his arm, on the navy wool, warm from the sun."

    a "Here's a new job, Constable. Your same word. Different meaning."
    
    a "Stop. Sit down. Take your boots off. Have a rest. You've been on duty for thirty-six years. I'm giving you the day off."

    "He studies you, his moustache twitching through several drafts of an answer."

    "Then, with the sigh of a man who's finished a group project without much help, the Constable lowers himself onto the black sand."
    
    "He sets his helmet beside him. He unlaces one boot, and pulls it off, and wiggles his toes in the warm sand, and closes his eyes."

    "And then, because he's a smart man and has been watching too, he tips his face up into the sun."

    st "Oh, that's nice. That's very nice, that is."

    "He opens his glove. The apple rolls out onto the sand. The worm leans out, takes one look at the sea, and says, reverently, {i}go,{/i} very quietly, as if to himself."

    hide stop
    hide worm
    with fadeout

    $ music("reflective")

    show rob soft

    "[rob_name] bends and picks up the sack. He holds it out to you."

    r "Happy birthday."

    "You open it."

    "Inside is a primary journal. Stapled. On your way to a thin plastic coil, but still bound. Soft and faded and smelling of a Wisconsin classroom in 1990."
    
    "And a crayon, stubby, worn down at an angle on one side, the way a five-year-old holds it, like a dagger."

    "You open the journal to the page. It falls open there on its own."

    "The apple and the worm. {i}Go!{/i} The round blue policeman. {i}Stop!{/i} And on the right edge of the drawing, the back leg and the striped back of a robber, running off the page with his iconic sack."

    "And under the drawing, the lined half. Blank. Exactly as you left it, thirty-six years ago."

    show ash sad

    a "You stole my journal."

    show rob neutral

    r "I stole it back. He was going to file it at dawn. And I thought..."

    "He rubs the back of his neck."

    r "I thought you might want to finish something. For once. For you."

    "He doesn't say {i}for me.{/i} He's standing on a beach at sunrise with no shirt and no mask, barely breathing, waiting for you to write down what happens to him."

    "You sit down on the black sand with the journal on your knees and the crayon in your fist. Like a dagger. Some things don't change. They could never get you to hold it correctly."

    "What do you write?"

    menu:
        "\"Then the robber stopped running. He turned around, and he waved.\"":
            $ c3_end = "wave"
        "\"Then the robber turned around, and the girl who drew him took his hand.\"":
            $ c3_end = "hand"
            $ sp()
        "\"Then the robber went to the beach, because the worm said so.\"":
            $ c3_end = "beach"

    "You write it in crayon, on the first line."

    "And then you keep going."

    "You don't plan to. Your hand just doesn't stop. The second line, and the third."

    "It comes like it always has. It sits like a fever under your skin until enough of it is on the page and you can breathe again."

    "What the cop did. What the worm said. How the sun felt. How the snow fell on the lane you built. The pegasus. The pockets. A cat at your feet."

    "You fill the lined half and you turn the page over and you fill the back of it, too, the way you did once, that first time. A long time ago, when all it took was the barest suggestion."

    $ music("heart full")
    $ cg("cg journal after", longdiss)

    "When you finally look up from the page, the drawing has changed."

    "The robber is all the way inside the picture now. He's turned around. He's facing you, grinning in his little crayon mask and his little crayon stripes, waving with one hand. His sack is open at his feet and spilling yellow stars and red hearts all over the green grass like the luckiest of charms."

    "His other hand is holding the hand of a tall stick-figure lady with long yellow crayon hair and a green crayon dress."

    "The blue policeman is sitting down on the grass with his helmet off beside him and his feet stretched out, eyes shut, three Z's floating over his head. The apple and the worm are there. No arms. You were five, not stupid."
    
    "The worm is still saying {i}Go!{/i}. Of course he is. That's his job. Somebody has to."

    "And the lined half is full. Every line, both sides, in wobbly crayon."

    $ ash_outfit = "dress"
    $ rob_outfit = "bare"
    $ light("dawn")
    scene bg beach dawn
    show ash soft at lpos
    show rob soft at gpos
    with dissolve

    "[rob_name] is smiling, a slow, wondering smile you haven't seen on him yet. He's looking down at his hands, turning them over, flexing the fingers, as if they're new."
    
    "He turns all the way around on the sand and back again, just because he can. He looks behind himself. He looks at the sea."

    r "I've never seen what was behind me."

    a "What's behind you?"

    show rob soft

    r "The sea. And the sun."

    "He turns back to you."

    r "And then you, when I turned around. Every time."

    "He kneels on the sand in front of you. He takes your face in his hands, the way he did in the water, and kisses you once, very gently, the way you'd close a book you loved."

    show ash sad

    a "What happens now?"

    "He doesn't answer right away. Behind him, the Constable is snoring. The worm is watching the surf. Up on the clifftop, in the silver grass, something orange sits and licks one white paw."

    r "Now you go home. It's your birthday. Your mom's going to call, and you're going to want to be there."

    a "And you?"

    show rob neutral

    r "I'll be right here. In the margins. I've got a beach now. And a very good ending."

    "He tucks a damp strand of hair behind your ear."

    r "But you'll be back. You've always got something started."

    show ash laugh

    a "I've got twelve things started. And a score more unfinished."

    show rob soft

    r "I know you do, Crayon."

    "He looks down at the journal in your lap."
    
    show rob wry
    
    r "They really mangled the handwriting, eh?"

    show ash flustered

    show rob laugh

    a "No, uh, that's pretty accurate actually. Mrs. Wisniewski sent me home with lined paper for penmanship practice in {i}third grade{/i}."

    show rob soft

    r "Third grade. That's when you decided you wanted to be a writer."

    show ash smile

    a "I did."

    r "You already were one, you know. You still are. Always have been."

    a "I think I understand that now."

    "He reaches out and turns the journal page in your lap. The next one. Blank drawing space at the top, blank lines underneath."

    r "So. [mc]."

    "His voice, saying it. Gentle and warm and absolutely certain. He has no idea whose words he's using. Or maybe he does."

    r "Why don't you try writing something else?"

    "You laugh. It comes out wet. You can't help it."

    show ash laugh

    a "That's all it ever takes, huh."

    r "The barest suggestion."

    hide rob
    hide ash
    with fadeout

    "{i}Mer-uh. Iht iht iht.{/i}"

    "Squat Box is at your elbow, tail up, looking at you with his whole clever face. He's ready when you are. He trots three steps up the beach and looks back. That way."

    "There's a painting up there, you realize, where the cliff meets the sand. A big one in a gilded frame, standing in the silver grass as if it grew there."
    
    "And in it, glowing like an open door, is a living room with fairy lights."

    stop music fadeout 2.0
    $ music("soft hurt")
    $ cg("cg gallery goodbye", longdiss)

    "You don't remember walking up the beach. You remember kneeling in front of the frame, in your damp green dress, on a polished floor that must be the Gallery after all, with the colored light of a hundred other worlds falling on you."

    "You remember the cat standing up on his hind legs, and putting his front paws on your knee, and pressing his forehead to yours."

    "His fur smells like a sunny windowsill. He's warm. He's purring so hard you feel it in your teeth."

    "You close your eyes. You cup the back of his head in your hand, his skull small and round and perfect under your palm. One tear goes, and you let it."

    a "Thank you, Squatty. Thank you for looking after me."

    "{i}Iht iht.{/i} Obviously."

    "Then he drops back to all fours and sits down beside the frame, tail wrapped around his white paws, the way he always sat. To see you safely out."

    "You follow him through."

    stop music fadeout 2.0
    scene black with whitefade

    $ ash_outfit = "home"
    $ light()
    scene bg home morning with longdiss
    $ music("start and continue")

    "Sunlight."

    "You're on the sectional, under the cardigan, in the slip, with one ankle propped on the opposite knee. The candles have burned down. The fairy lights are still on, glowing faintly in the morning like they forgot to go to bed."
    
    "Through the window the sun is pouring in gold across the floor, and outside, the maples on the hill are still holding their red and orange, under a high blue sky."

    "The eighteenth of November. Forty-one."

    show ash neutral at lpos with dissolve

    "You lie there for a minute, the way you do on a morning with no alarm, when sleep doesn't want to let go and doesn't have to."

    "A dream. Obviously. A very, very good one."

    "Or a fever, that started out in the world this time, and cozied up under your skin like a warm bath."

    "You sit up, and swing your feet down onto the warm floor, and stop."

    "There's black sand in your socks."

    show ash surprised

    "Fine and glittering, caught in the cotton between your toes. You stare at it. You rub some between your finger and thumb. It squeaks."

    "On the arm of the sectional, right where it landed last night, there's a single white almond-blossom petal. It's not glowing anymore. It's just a petal. You pick it up very carefully."

    "On the scroll above the couch, the painted branches are exactly as they've always been."

    "Almost exactly. You'd swear there's one fewer blossom on the lowest branch."

    $ sfx("phone_buzz")

    "Your phone buzzes on the coffee table. Then again."

    show ash smile

    "Mom."

    "You pick up. You always will."

    mom "Happy birthday from the past!! I love you tons!"

    a "Thank you, from the future!"

    mom "Did you do anything fun last night? You sound different. You sound... I don't know. Did you sleep?"

    "You look at the sand on your socks. You look at the petal in your hand."

    a "I went to the beach."

    mom "In {i}November?{/i}"

    show ash laugh

    a "It was a really nice beach."

    "She tells you about her day. About the weather, which is brown and cold and grey, the way it always was on your birthday. About how she went out at lunch when the sun came through, and stood there with her eyes closed for a minute, and thought about you."

    show ash smile

    "You don't tell her that somebody else does it now, too. You just say you love her, and she says it back, and then she says she'll let you go, and you hear the smile in her voice."

    "When you hang up there are texts waiting."

    txt "Karen: HAPPY BIRTHDAY ASHLEY!!! 💖✨🌸🌟🎂🌟🌸✨"

    "Then you receive a dissertation on your star chart."

    txt "...For yours we have to factor in the houses, which is 4th focus. Cancer Moon energy. Even more dreamy and cozy. lol it put freaky instead of dreamy.. which freaky does apply too cuz Cancer and Moon is associated with lunacy and Cancerian humor can be wacky at times"

    txt "but it's the mothering place 🌸 how do you spell your blanket's name? The sweet energy of home sweet home, care, security, safety, love and lenience, unconditional constant, sigh of relief, breath of fresh air, hmm, hmm, hmmm, hmmmm,  HHMMMMMMMMMMM lol hopefully you caught my reference"

    show ash laugh

    "You laugh. You got the reference. You think of Kiki. Of those afternoon naps with your mother. Where the contented {i}hm{/i}s of drifting off to sleep escalated until they were great big roaring {i}HMMM{/i}s and it became a daily game of who would do it first."

    show ash soft

    "There are forty-two more messages about what the stars were up to when you were born. You'll read them later, because she took the time to write them."

    "Then another text."

    show ash laugh

    txt "Tim: hbd sis"

    "You laugh out loud, alone, in your sunny living room. Some things don't change. You wouldn't want them to."

    show ash neutral

    "The notebook's still on the coffee table. This year's list. {i}Smile waves{/i}, with February's handwriting, terrible as it ever was. Even a good teacher can't fix everything."
    
    "You know what smile waves mean now. You think you know what it meant then, too."
    
    "You're keeping it. Both ways."

    "You pick up the pen. One more entry. What goes on the list?"

    menu:
        "\"Smile waves. (I know what it means now.)\"":
            $ c3_list = "smile"
            "You draw a little arrow from the new line to the old one. Neat. A matched pair."
        "\"The relentless optimism of a worm in an apple.\"":
            $ c3_list = "worm"
            "Somewhere, you're sure, a tiny voice is shouting GO about it."
        "\"Being turned around to.\"":
            $ c3_list = "turn"
            $ sp()
            "You don't explain it. Nobody reading the list will understand it. That's fine. It isn't for them."

    "You set the pen down. You pick up your phone again."

    "Your thumb hovers for a second over a search bar. Then it types, without waiting for the rest of you to finish deciding:"

    txt "flights to Jeju"

    "There's one this Saturday. Not even expensive. It's always been right there, an hour away, any weekend. It's always there. That's exactly the problem."

    "Somewhere in the back of your skull, very small and very green and very sure of itself, a voice says {i}GO.{/i}"

    menu:
        "Book it.":
            $ c3_book = "book"
            "You book it."
        "Book it. Window seat.":
            $ c3_book = "window"
            "You book it. Window seat. You want to see it coming in, the black rocks and the blue water, from above. You've seen it from above once already."
        "Book it, then text the group chat a photo of the confirmation.":
            $ c3_book = "chat"
            "You book it, screenshot it, and send it to a group chat that's been quiet for months. It lights up within a minute. Laughing emojis. A {i}FINALLY.{/i} Someone asking if you're bringing them a tangerine."

    show ash smile

    "Then you get up off the couch, in your socks, on the warm floor, in the sun. You slide across the good smooth floor to the kitchen to make coffee, a la Risky Business, because you're forty-one and you've stopped waiting for permission to do anything."

    "On the way past the scroll, you stop."

    "You tip your face up to the sunlight coming through the window. You close your eyes. You let it lie warm on your cheeks."

    "And for one second, you'd swear on anything, from somewhere behind the almond blossoms, you hear someone laugh, low and delighted, like he caught you."

    stop music fadeout 3.0
    scene black with blackfade

    ## Epilogue: the Robber
    call pov_card(rob_name)
    $ music("heart full")
    $ light("dawn")
    scene bg beach dawn with longdiss

    "On a black-sand beach at the edge of the Margin, the sun climbs out of the sea."

    "A man sits on the sand with his shirt off and his mask nowhere at all, his face tipped up and his eyes closed."
    
    "An orange cat sits on his feet, because the cat has decided they're his now. A little way off, a police constable snores in his socks, his helmet full of sand. A worm in an apple watches the waves come in and says {i}go{/i} to each one, softly, as encouragement."

    "In the man's lap is a primary journal, open to a page with a drawing on it, and every line underneath filled in crayon."

    "He has read it a dozen times."

    "He is going to read it again. He knows how it ends. That's the best part. He knows how it ends, and he can read it anyway, and it's still good every time."
    
    "He wonders if that's what she meant, all those years, about reading the last page. He wonders if it's what she meant by anything. He'll ask her."

    "Because she'll be back. She has a whole notebook of things she started. A whole hard drive. A whole cloud. A whole big, beautiful brain. A great big overflowing heart."

    "And when she comes, he'll be facing the right way."

    "He turns the journal to the next page. Blank drawing space at the top. Blank lines underneath."

    "He smiles at it, with his eyes closed, in the sun."

    "Somewhere down the beach, a breeze rises in the silver grass, lulls, and starts up again, more insistent. The way a breeze does when it has something to say."

    "There's always something to say. Always a story to tell."

    stop music fadeout 3.0
    scene black with blackfade
    return


## The PG path through the beach (chosen in the water).
label c3_pg:
    $ music("sweet romance")
    $ cg("cg beach surf", longdiss)

    "He closes the last arm's length of sea between you, takes your face in both hands, and kisses you."

    "A wave picks that exact moment to break over you both, white and roaring and warm as bathwater, and neither of you lets go. Salt on your lips. Salt on his."
    
    "His fingers slide back into your wet hair, and your hands find his chest and stay there, flat over his heart, which is going like it's trying to get out and get to you."

    "In the snow he kissed you like he was asking. Here he kisses you like he's been told yes, and intends to spend a very long time being grateful about it."

    "Far out at sea, the storm opens violet and goes dark again. The moon lays its silver road across the water straight to where you're standing. Your dress floats out around you, heavy and dark, the pockets full of ocean, and you have never in your life cared less about anything."

    "When he finally lifts his head, he doesn't go far. He rests his forehead against yours, and the two of you stand there in the warm top layer of the sea, breathing the same air, while the waves push and pull at your legs like they're trying to rock you to sleep."

    r "Thirty-six years on the wrong side of the glass."

    a "You're on the right side now."

    r "I know. I keep checking."

    "You laugh against his mouth, and he laughs back. A wave knocks you both sideways and he catches you, and doesn't let go after, and you walk up out of the water like that: his arm around your waist, your head on his shoulder, your dress swishing heavy and dripping at your thighs, all the way up the black sand to where he dropped his coat."

    "He spreads it out. He lies down on it and holds out one arm, and you lie down beside him, and then half on top of him, because he's warm and the coat is warm and the wind off the sea is not. You fit there like you were drawn to."

    jump c3_after

