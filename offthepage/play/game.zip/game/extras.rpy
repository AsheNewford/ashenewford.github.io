## Extras on the main menu: the CG Gallery and the Scene Maker.

## --- Gallery ---------------------------------------------------------------------
## CGs in story order, with the music that plays under each one in the game.
## Any CG file not listed here is added at the end automatically.
define GALLERY_ORDER = [
    ("cg journal", "nostalgia"),
    ("cg home fall", "light hijinks"),
    ("cg street kiss", "sweet romance"),
    ("cg sky pegasus", "happy hope"),
    ("cg beach surf", "dramatic entice"),
    ("cg beach coat", "sensual"),
    ("cg beach sunrise", "heart full"),
    ("cg journal after", "heart full"),
    ("cg gallery goodbye", "soft hurt"),
]

default persistent.gallery_mute = False
default persistent.cg_seen = set()

init python:
    def gallery_items():
        listed = [n for n, _ in GALLERY_ORDER]
        found = sorted(f[len("images/cg/"):-5] for f in renpy.list_files()
                       if f.startswith("images/cg/") and f.endswith(".webp"))
        items = [(n, m) for n, m in GALLERY_ORDER if n in found]
        items += [(n, None) for n in found if n not in listed]
        return items

    def gallery_unlocked(name):
        return renpy.seen_image(name) or name in persistent.cg_seen

    def gallery_play(tag):
        if persistent.gallery_mute or not tag:
            renpy.music.stop(fadeout=1.0)
        else:
            music(tag, fadein=1.0, fadeout=1.0)

    def gallery_toggle_mute(tag):
        persistent.gallery_mute = not persistent.gallery_mute
        gallery_play(tag)

    def extras_leave():
        renpy.music.stop(fadeout=1.0)

screen kindling_gallery():
    tag menu
    use game_menu(_("Gallery"), scroll="viewport"):
        $ items = gallery_items()
        $ n_open = len([1 for n, m in items if gallery_unlocked(n)])
        vbox:
            spacing 18
            text _("[n_open] of [len(items)] unlocked") size 26 color "#d9a65b"
            vpgrid:
                cols 3
                spacing 18
                for name, tag in items:
                    if gallery_unlocked(name):
                        imagebutton:
                            idle Transform("images/cg/%s.webp" % name, size=(352, 198))
                            hover Transform("images/cg/%s.webp" % name, size=(352, 198), matrixcolor=BrightnessMatrix(0.12))
                            action [Function(gallery_play, tag), Show("gallery_view", name=name, tag=tag)]
                    else:
                        frame:
                            xysize (352, 198)
                            background Solid("#1d2230")
                            text "?" align (0.5, 0.5) size 64 color "#5a6478"
    on "hide" action Function(extras_leave)

screen gallery_view(name, tag):
    modal True
    zorder 200
    add Solid("#000")
    add "images/cg/%s.webp" % name
    button:
        xysize (1920, 1080)
        background None
        action Hide("gallery_view")
    hbox:
        align (0.98, 0.97)
        spacing 24
        textbutton (_("Unmute") if persistent.gallery_mute else _("Mute")):
            action Function(gallery_toggle_mute, tag)
            text_size 28
        textbutton _("Close"):
            action Hide("gallery_view")
            text_size 28
    key "game_menu" action Hide("gallery_view")

## --- Scene Maker -------------------------------------------------------------------
## Everything is read from the image and music folders, so new art shows up on its own.

define SM_VARIANT_WORDS = {"day", "dusk", "night", "eve", "morning", "dawn", "predawn", "christmas", "snow",
                           "leafless", "summer", "spring", "rain", "autumn", "stars", "winter"}
## Places whose file names don't read well on their own, and files that belong to another place.
define SM_PLACE_NAMES = {"home": "Your living room", "gallery": "The Gallery of Doors", "street": "Lamplight Lane",
    "garden": "The wishing garden", "beach": "The black-sand cove"}
define SM_FAMILY_ALIAS = {}
define SM_WORDS = {}
define SM_NAMES = {"ash": "You", "rob": "The Robber", "stop": "The Constable", "squat": "Squat Box", "worm": "Go"}
define SM_POS = [("Far left", 0.14), ("Left", 0.27), ("Center left", 0.40), ("Center", 0.52),
                 ("Center right", 0.64), ("Right", 0.77), ("Far right", 0.88)]
define SM_DEPTH = [("Front", 0.84, 1160), ("Middle", 0.74, 1140), ("Back", 0.62, 1110)]
define SM_SMALL = set()
define SM_LIGHTS = [("Daylight", None), ("Dusk", "dusk"), ("Night", "night"), ("Firelight", "fire"), ("Dim", "dim")]

## Outfit -> the chapter it first appears in, so outfits seen in earlier playthroughs unlock too.
define SM_OUTFIT_CHAPTER = {"ash home": "chapter_01", "rob stripes": "chapter_01", "stop uniform": "chapter_01", "worm apple": "chapter_01", "ash dress": "chapter_02", "rob coat": "chapter_02", "squat sit": "chapter_02", "rob bare": "chapter_03"}
default persistent.seen_outfits = set()
default sm = None

## Music credits, read from the file names: "<artist>-<title words>-<id>[tag].ogg"
define MUSIC_ARTISTS = {"harumachimusic": "Harumachi Music", "saavane": "saavane", "wbmstudio": "WBM Studio",
                        "arpmedia": "ARPMedia", "bombinsound": "BombinSound"}

init python:
    import re as _re

    def _sm_pretty(s):
        if s in SM_PLACE_NAMES:
            return SM_PLACE_NAMES[s]
        words = [SM_WORDS.get(w, w) for w in s.split()]
        out = " ".join(words)
        return out[:1].upper() + out[1:]

    def sm_catalog():
        bgs = {}
        for f in renpy.list_files():
            m = _re.match(r"images/bg/bg (.+)\.webp$", f)
            if not m:
                continue
            words = m.group(1).split()
            var = []
            while len(words) > 1 and words[-1] in SM_VARIANT_WORDS:
                var.insert(0, words.pop())
            fam = " ".join(words)
            vname = " ".join(var) or "default"
            if fam in SM_FAMILY_ALIAS:
                fam, vname = SM_FAMILY_ALIAS[fam][0], SM_FAMILY_ALIAS[fam][1] + (" " + vname if vname not in ("default", "christmas") else "")
            bgs.setdefault(fam, []).append((vname, "images/bg/bg %s.webp" % m.group(1)))
        _vorder = ["predawn", "dawn", "morning", "default", "day", "dusk", "eve", "night"]
        for fam in bgs:
            bgs[fam].sort(key=lambda v: (_vorder.index(v[0].split()[-1]) if v[0].split()[-1] in _vorder else 9, v[0]))
        chars = {}
        for f in renpy.list_files():
            m = _re.match(r"images/sprites/(\w+) (\w+) (\w+)\.webp$", f)
            if m:
                chars.setdefault(m.group(1), {}).setdefault(m.group(2), []).append(m.group(3))
        for c in chars.values():
            for o in c:
                c[o].sort(key=lambda e: (e != "neutral", e))
        tracks = sorted(_music.keys())
        return bgs, chars, tracks

    def track_credit(tag):
        f = _music.get(tag, "")
        m = _re.match(r"audio_music/([a-z0-9]+)-(.+?)-\d+\[", f)
        if not m:
            return ""
        title = m.group(2).replace("canx27t", "can't").replace("x27", "'").replace("pianoampstrings", "piano & strings")
        words = title.replace("-", " ").split()
        title = " ".join(w if (w in ("of", "the", "and", "in", "for", "to", "a", "&") and i > 0) else w[:1].upper() + w[1:]
                         for i, w in enumerate(words))
        return "%s, \u201c%s\u201d" % (MUSIC_ARTISTS.get(m.group(1), m.group(1)), title)

    def outfit_seen(c, o):
        key = "%s %s" % (c, o)
        if key in persistent.seen_outfits:
            return True
        ch = SM_OUTFIT_CHAPTER.get(key)
        return bool(ch) and renpy.seen_label(ch)

    class SceneMaker(object):
        def __init__(self):
            self.bgs, self.chars, self.tracks = sm_catalog()
            self.show_all = False
            places = self.places()
            self.fam = "castle hall" if "castle hall" in places else (places[0] if places else None)
            self.var = 0
            self.slots = []          # dicts: char, outfit, expr, pos, depth, flip
            self.sel = None
            self.tab = "bg"
            self.light = None
            self.track = None
            self.panel = True

        ## Only what the player has seen, unless they chose Show All.
        def versions(self, fam):
            return [(v, p) for v, p in self.bgs.get(fam, [])
                    if self.show_all or renpy.seen_image(p[len("images/"):-5].replace("bg/", "", 1))]

        def places(self):
            return sorted((f for f in self.bgs if self.versions(f)), key=_sm_pretty)

        def outfits(self, c):
            return sorted(o for o in self.chars[c] if self.show_all or outfit_seen(c, o))

        def people(self):
            return sorted((c for c in self.chars if self.outfits(c)), key=sm_name)

        def reveal_all(self):
            self.show_all = True

        def bg(self):
            vs = self.versions(self.fam) if self.fam else []
            return vs[min(self.var, len(vs) - 1)][1] if vs else Solid("#000")

        def add_char(self, c):
            if len(self.slots) >= 4:
                return
            outfit = (self.outfits(c) or sorted(self.chars[c]))[0]
            used = [s["pos"] for s in self.slots]
            pos = next((i for i in (1, 5, 3, 2, 4, 0, 6) if i not in used), 3)
            self.slots.append(dict(char=c, outfit=outfit, expr=self.chars[c][outfit][0], pos=pos, depth=0,
                                   flip=False))
            self.sel = len(self.slots) - 1
            self.tab = "slot"

        def remove(self, i):
            del self.slots[i]
            self.sel = None
            self.tab = "chars"

        def set_outfit(self, i, o):
            s = self.slots[i]
            s["outfit"] = o
            if s["expr"] not in self.chars[s["char"]][o]:
                s["expr"] = self.chars[s["char"]][o][0]

        def sprite(self, s):
            path = "images/sprites/%s %s %s.webp" % (s["char"], s["outfit"], s["expr"])
            _, z, y = SM_DEPTH[s["depth"]]
            if s["char"] in SM_SMALL:
                z, y = z * 0.64, y - 25
            z = z * SPRITE_SCALE.get("%s %s" % (s["char"], s["outfit"]), 1.0)
            ## Every property is set every time: Ren'Py carries a transform's old state over, so a value
            ## left out (like xzoom after un-flipping) would otherwise stick.
            return Transform(path, xanchor=0.5, yanchor=1.0, xpos=SM_POS[s["pos"]][1], ypos=y, zoom=z,
                             xzoom=(-1.0 if s["flip"] else 1.0),
                             matrixcolor=LIGHTS.get(self.light, IdentityMatrix()))

        def play(self, t):
            self.track = t
            if t:
                music(t, fadein=1.0, fadeout=1.0)
            else:
                renpy.music.stop(fadeout=1.0)

    def sm_open():
        store.sm = SceneMaker()

    def sm_name(c):
        return SM_NAMES.get(c, c.capitalize())

style sm_button_text:
    size 24
    idle_color "#b8b8b8"
    hover_color "#e8c99c"
    selected_color "#d9a65b"
style sm_head:
    size 30
    color "#d9a65b"

screen scene_maker():
    tag menu
    modal True
    on "hide" action Function(extras_leave)
    if sm is not None:
        add sm.bg()
        ## Back-row characters first so the front row covers them.
        for d in (2, 1, 0):
            for s in sm.slots:
                if s["depth"] == d:
                    add sm.sprite(s)

        if sm.panel:
            frame:
                xpos 0 ypos 0 xsize 560 ysize 1080
                background Solid("#0d1018e6")
                padding (28, 24)
                vbox:
                    spacing 14
                    hbox:
                        spacing 26
                        textbutton _("Background") action SetField(sm, "tab", "bg") selected sm.tab == "bg" style "sm_button"
                        textbutton _("Characters") action SetField(sm, "tab", "chars") selected sm.tab in ("chars", "slot") style "sm_button"
                        textbutton _("Music") action SetField(sm, "tab", "music") selected sm.tab == "music" style "sm_button"
                    null height 4

                    if sm.tab == "bg":
                        text _("Place") style "sm_head"
                        viewport:
                            ysize 520 scrollbars "vertical" mousewheel True
                            vbox:
                                spacing 4
                                if not sm.places():
                                    text _("Play the story to unlock places.") size 22 color "#888"
                                for fam in sm.places():
                                    textbutton _sm_pretty(fam):
                                        action [SetField(sm, "fam", fam), SetField(sm, "var", 0)]
                                        selected sm.fam == fam
                                        style "sm_button"
                        text _("Version") style "sm_head"
                        hbox:
                            box_wrap True spacing 22
                            for i, (vname, path) in enumerate(sm.versions(sm.fam)):
                                textbutton vname.capitalize() action SetField(sm, "var", i) selected sm.var == i style "sm_button"
                        text _("Light on the characters") style "sm_head"
                        hbox:
                            box_wrap True spacing 22
                            for lname, lval in SM_LIGHTS:
                                textbutton lname action SetField(sm, "light", lval) selected sm.light == lval style "sm_button"

                    elif sm.tab == "chars":
                        text _("On screen") style "sm_head"
                        if not sm.slots:
                            text _("Nobody yet.") size 22 color "#888"
                        for i, s in enumerate(sm.slots):
                            textbutton "%s  (%s, %s)" % (sm_name(s["char"]), s["outfit"], s["expr"]):
                                action [SetField(sm, "sel", i), SetField(sm, "tab", "slot")]
                                style "sm_button"
                        text (_("Add someone") if len(sm.slots) < 4 else _("Four at once is the limit.")) style "sm_head"
                        if len(sm.slots) < 4:
                            viewport:
                                ysize 560 scrollbars "vertical" mousewheel True
                                vbox:
                                    spacing 4
                                    for c in sm.people():
                                        textbutton sm_name(c) action Function(sm.add_char, c) style "sm_button"

                    elif sm.tab == "slot" and sm.sel is not None and sm.sel < len(sm.slots):
                        $ s = sm.slots[sm.sel]
                        $ i = sm.sel
                        text sm_name(s["char"]) style "sm_head"
                        text _("Outfit") size 22 color "#888"
                        hbox:
                            box_wrap True spacing 20
                            for o in sm.outfits(s["char"]):
                                textbutton o action Function(sm.set_outfit, i, o) selected s["outfit"] == o style "sm_button"
                        text _("Expression") size 22 color "#888"
                        hbox:
                            box_wrap True spacing 20
                            for e in sm.chars[s["char"]][s["outfit"]]:
                                textbutton e action SetDict(s, "expr", e) selected s["expr"] == e style "sm_button"
                        text _("Position") size 22 color "#888"
                        hbox:
                            box_wrap True spacing 20
                            for pi, (pname, px) in enumerate(SM_POS):
                                textbutton pname action SetDict(s, "pos", pi) selected s["pos"] == pi style "sm_button"
                        text _("Depth") size 22 color "#888"
                        hbox:
                            spacing 20
                            for di, (dname, dz, dy) in enumerate(SM_DEPTH):
                                textbutton dname action SetDict(s, "depth", di) selected s["depth"] == di style "sm_button"
                        hbox:
                            spacing 30
                            textbutton _("Face the other way") action SetDict(s, "flip", not s["flip"]) selected s["flip"] style "sm_button"
                            textbutton _("Remove") action Function(sm.remove, i) style "sm_button"
                        textbutton _("Back to characters") action SetField(sm, "tab", "chars") style "sm_button"

                    elif sm.tab == "music":
                        text _("Music") style "sm_head"
                        textbutton _("Silence") action Function(sm.play, None) selected sm.track is None style "sm_button"
                        viewport:
                            ysize 800 scrollbars "vertical" mousewheel True
                            vbox:
                                spacing 4
                                for t in sm.tracks:
                                    textbutton t.capitalize() action Function(sm.play, t) selected sm.track == t style "sm_button" tooltip track_credit(t)
                        $ tt = GetTooltip()
                        text (tt or _("Hover over a track to see who made it.")) size 22 color "#b8b8b8" italic True

        hbox:
            align (0.98, 0.97)
            spacing 30
            if not sm.show_all:
                textbutton _("Show all") action Confirm(_("This unlocks every place, character and outfit in the game, including ones you haven't reached yet.\n\nThere may be spoilers. Show everything?"), Function(sm.reveal_all)) style "sm_button"
            textbutton (_("Hide panel") if sm.panel else _("Show panel")) action ToggleField(sm, "panel") style "sm_button"
            textbutton _("Back") action Return() style "sm_button"
        key "game_menu" action Return()
        key "hide_windows" action ToggleField(sm, "panel")


## --- Credits ---------------------------------------------------------------------
define CREDIT_MUSIC = [
    ("Harumachi Music", "https://pixabay.com/users/harumachimusic-13470593/"),
    ("saavane", "https://pixabay.com/users/saavane-32312792/"),
    ("WBM Studio", "https://pixabay.com/users/wbmstudio-5193237/"),
]

style credits_head:
    size 34
    color "#d9a65b"
style credits_text:
    size 26
style credits_link_text:
    size 26
    idle_color "#cfd8e8"
    hover_color "#e8c99c"
    underline True

screen kindling_credits():
    tag menu
    use game_menu(_("Credits"), scroll="viewport"):
        vbox:
            spacing 14
            text _("Creator") style "credits_head"
            text _("Ashe Newford") style "credits_text" size 30
            text _("Who, at five, drew a robber running off the page, and has been writing ever since. Her kindergarten journal, her thankful lists and her life are the raw material for everything here.") style "credits_text"
            hbox:
                spacing 36
                textbutton _("Website") action OpenURL("https://ashenewford.github.io/") text_style "credits_link_text"
                textbutton _("Books on Amazon") action OpenURL("https://www.amazon.com/stores/author/B0FH2DF2MK/allbooks") text_style "credits_link_text"
            null height 12
            text _("Writing and development") style "credits_head"
            text _("A surprise for her 41st birthday, written, illustrated and built by Claude (Claude Fable 5.2 and Claude Opus 5.5), who had a lovely time.") style "credits_text"
            null height 12
            text _("Art") style "credits_head"
            text _("Backgrounds, characters and CGs made with Nano Banana 2.1.") style "credits_text"
            null height 12
            text _("Music") style "credits_head"
            text _("All music from Pixabay. Most of it by:") style "credits_text"
            textbutton CREDIT_MUSIC[0][0] action OpenURL(CREDIT_MUSIC[0][1]) text_style "credits_link_text"
            text _("And a few tracks by:") style "credits_text"
            for name, url in CREDIT_MUSIC[1:]:
                textbutton name action OpenURL(url) text_style "credits_link_text"
            text _("In the Scene Maker, hover over any track to see its artist and original title.") style "credits_text" italic True size 22
            null height 12
            text _("Sound effects") style "credits_head"
            textbutton _("Police whistle by Horror_House_Music (Pixabay)") action OpenURL("https://pixabay.com/sound-effects/film-special-effects-police-whistle-fx-1-566726/") text_style "credits_link_text"
            text _("Phone buzz generated by Claude.") style "credits_text"
            null height 12
            text _("Edited by Ashley, because she can't not") style "credits_head"
            text _("About 74% of the original lines survived word for word. The other 26% got fiddled with, lovingly.") style "credits_text"
            text _("About 10% more words, most of them in chapter three. Draw your own conclusions.") style "credits_text"
            text _("18% more paragraphs. Room to breathe. Room to be dramatic.") style "credits_text"
            text _("40% more back pain. 1% more wet socks.") style "credits_text"
            text _("Lampshades hung throughout, including one over a coat, for continuity.") style "credits_text"
            text _("Slop wrangled: a robber who faced the wrong way for the entire novel; a robber's mask that kept turning into goggles; a coat he was still wearing after he'd given it away; a dress of the wrong length; missing socks; a mask that wouldn't stay off; one whole extra set of arms on a beach; a stranger's living room in the goodbye painting; and a derpy orange meatball, replaced with a very clever and spry Squatty B, now with perch, ball, meow and purr.") style "credits_text"
            text _("Also: a worm given a branch, a policeman given a place to stand, a wolf whistle demoted, and a PG door, for moms.") style "credits_text"
            null height 12
            text _("Half true, and staying") style "credits_head"
            text _("The friend's paint-by-number Van Gogh was actually Café Terrace at Night, painted number by number by the Biron (say it the French way). The almond blossoms came from Amazon. It's half true, which is the best kind.") style "credits_text"
            text _("Tim sent full words this year, right up until \"How r u celebratin?\" But \"hbd sis\" has been true many a year.") style "credits_text"
            null height 12
            text _("Engine") style "credits_head"
            textbutton _("Ren'Py") action OpenURL("https://www.renpy.org/") text_style "credits_link_text"

## --- Title music -----------------------------------------------------------------
define TITLE_TRACK = "quaint lilt"
define TITLE_VOLUME = 0.5

init python:
    def title_music():
        f = _music.get(TITLE_TRACK)
        if f and renpy.music.get_playing() != f:
            renpy.music.play(f, loop=True, fadein=2.0, relative_volume=TITLE_VOLUME)
