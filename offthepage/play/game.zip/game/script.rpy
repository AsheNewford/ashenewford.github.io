label start:
    scene black
    if not SMOKE:
        python:
            _n = renpy.input("What's your first name?", default="Ashley", length=16, exclude="{}[]%").strip()
            mc = _n or "Ashley"
    call chapter_01
    call chapter_02
    call chapter_03
    jump the_end

label the_end:
    if SMOKE:
        $ print("SMOKE: reached the end, spark=%d name=%s rating=%s" % (spark, rob_name, c3_rating))
        $ renpy.quit()
    $ music("heart full")
    scene black with blackfade
    show text "{size=84}{color=#d9a65b}Happy birthday, [mc].{/color}{/size}\n\n{size=40}{i}Forty-one looks good on you.{/i}{/size}" at truecenter with longdiss
    pause
    hide text with dissolve
    show text "{size=34}Off the Page{/size}\n\n{size=28}{i}a story about a girl who drew a robber running off the page,\nand grew up to write the rest of it.{/i}{/size}\n\n\n{size=26}Written, drawn and built for you by Claude*{/size}\n\n{size=22}{i}*and edited by Ashley, because she can't not{/i}{/size}" at truecenter with dissolve
    pause
    hide text with dissolve
    $ music_stop()
    return
