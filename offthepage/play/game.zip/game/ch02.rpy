## Chapter Two: Go!

default c2_wish = None
default c2_squat = None
default c2_squat_seen = set()
default c2_squat_more = True
default c2_kiss = None

label chapter_02:
    call chapter_card("Chapter Two", "Go!")

    $ ash_outfit = "home"
    $ rob_outfit = "stripes"
    $ light("night")
    scene bg street night with slowfade
    $ music("quaint")

    "You come out of the painting at a run, onto cobblestones wet and shining like they've been polished for company."

    "And you stop, because you have to. Because nobody could run through this."

    show ash surprised at lpos with dissolve

    "A narrow street climbs away from you between tall, thin townhouses, every one of them showing off. Venetian Gothic arches with stone tracery carved fine as lace. Pediments. Friezes. Moulding on the moulding. Little wrought-iron balconies spilling flowers. Stained-glass windows burn ruby and sapphire and gold, and black iron gas lamps glow amber up and down both sides."
    
    "And over all of it the old trees lean in from either side of the lane until their branches meet overhead in an arch, still holding every leaf they've got, red and amber and gold."

    "A breeze comes down the lane. It rises in the leaves, lulls, and starts up again, more insistent, the way a breeze does when it has something to say. A handful of leaves lifts off the cobbles and goes swirling around your ankles, all floaty and willy-nilly, witchy as anything."

    show rob smile at gpos with dissolve

    "[rob_name] has stopped beside you. He isn't looking at the street. He's looking at you looking at it."

    r "Do you like it?"

    "You've written a hundred thousand words this year and you can't find one."

    a "It's... who {i}built{/i} this?"

    show rob wry

    r "You did."

    show ash neutral

    a "I've never seen this street in my life."

    r "Cobblestones. Iron work. Gas lamps. All that old-timey..."

    "He searches for the exact word, and finds it, and says it with obvious delight."

    r "{i}Shit.{/i}"

    "You know that phrase. You wrote that phrase. This year."

    r "{i}Tree-lined streets where the canopies touch overhead. Stained glass. Architecture that is {b}extra.{/b} Who thought the underside of a random door arch needed a staggering amount of carving? Venetians, for one, that's who.{/i}"

    show ash surprised

    a "That's my list."

    show rob soft

    r "Eight years of lists. Every little thing you ever stopped to notice and wrote down. The Margin keeps it. Somebody had to build the place out of something, and you kept handing us such good materials."

    "You look up the lane again, and now you can see it. The lamp that flares a little brighter when you look at it, the way a crosswalk light turns green just as you reach it on a particularly good day. Window boxes spilling the last flowers of the year. Leaves wrapped around a tree trunk like it's wearing a shawl."

    "Your whole life, the little things. Built into a city. Lit up. Waiting for you to come and walk down the middle of it."

    "You don't cry. You're on a schedule. But your throat does something complicated, and [rob_name], to his eternal credit, pretends not to notice and lets you stand there for a moment longer than the Constable's warrant would warrant."

    $ whistle(0.2)

    "Behind you, faint and far, a whistle."

    show rob neutral

    r "He's a few streets back. He gets lost in the Gallery; all the frames look like doors to him. We've got a minute."

    show ash wry

    a "Then you can use it to explain why I'm running through a fantasy city at midnight in a slip and a pair of socks."

    "The cobbles are cold. The socks are thin. The breeze, which has a lot to say, is saying most of it up the back of your slip."

    show rob laugh

    r "Yeah. I noticed. I've been very carefully noticing, in between very carefully not-noticing."
    
    "He looks up and down the street, thoughtful."

    r "There's a place for that. Two streets over. You wrote it when you were six."

    hide rob
    hide ash
    with fadeout

    $ light("night")
    scene bg garden night with slowfade
    $ music("quaint lilt")

    "Through a black iron gate. Into a walled garden."

    "Old rose-colored brick hung with ivy and the last climbing roses of the year. A tiled fountain murmuring to itself. A mossy stone bench, two gas lamps, a crescent moon like somebody clipped a fingernail and left it on the sky. Red and gold leaves on the flagstones."

    "And in the middle, glowing from the inside out, a bush."

    show ash surprised at lpos
    show rob smile at gpos
    with dissolve

    "It's round, glossy, dark-leaved, and every branch is hung with impossible fruit. Wrapped sweets in twists of shiny paper. Candies like jewels. Gold coins, actual gold coins, growing on little stems. Tiny glass jars glowing like fireflies, paper lanterns no bigger than plums, little parcels done up with ribbon."

    show ash laugh

    a "Candy and money."

    r "Strong opening."

    a "I drew it in crayon scribbles. It was a {i}circle.{/i} I spelt \"grew\" {i}\"gire\"{/i}."

    r "It {i}gired{/i} all right. It's had thirty-five years to work on itself. Same as you."

    show ash neutral

    a "How does it work?"

    show rob wry

    r "Same as you wrote it. You stand in front of it and you say what you want, out loud, and it grows. The out loud part's important. Most people are terrible at it."

    "He gives you a look."

    r "Some people especially."

    "Before you can ask what that's supposed to mean, or decide whether or not to be defensive, he steps up to the bush. He clears his throat like a man about to give a toast, and says:"

    r "A dress for her. Warm. Something she'd feel like a sex goddess in, while also being able to run from the police."

    "A pause."

    r "With pockets."

    show ash surprised

    "The bush rustles. A branch at the height of your hand swells and bends and puts out, like a bud opening at time-lapse speed, a parcel tied with green velvet ribbon."

    a "Pockets?"

    show rob soft

    r "{i}The way pockets on a dress are so enthusiastically loved by every woman I've ever met. I don't think a single other thing on earth has such a universally high approval rating.{/i}"

    "He recites it word for word. Your 2025 list. In his voice it sounds like a love letter. You suppose it is."

    show ash flustered

    a "You've {i}memorized{/i} them."

    r "I've had a lot of time. And they're good. They're the best thing anyone's ever written about being alive, and you post them once a year next to photos of mashed potatoes and turkey."

    "He plucks a second parcel for himself, wrapped in plain brown paper, and holds it up."

    show rob wry

    r "And I'd like to stop looking like evidence, circumstantial or otherwise."

    hide rob
    hide ash
    with fadeout

    "You change behind the bush. He changes on the far side of the fountain with his back very conspicuously turned, and you are very conspicuously not looking either. ...Except for the one time you are, and catch the long line of his bare back in the lamplight, and look away fast, and hear him laugh like he felt it."

    $ ash_outfit = "dress"
    $ rob_outfit = "coat"

    "Emerald velvet. A sweetheart neckline that has a lot of confidence in your collarbones. Off the shoulder. A full skirt that swishes when you turn, which you do, twice, alone behind a magic bush. Warm, somehow, despite how little of it there is, as though the velvet were lined with a sunny afternoon."

    "You put your hands in the pockets. They're deep. Your whole hands disappear. You make a small involuntary sound of pure joy."

    show ash smile at lpos
    show rob smile at gpos
    with dissolve

    "When you come out, he has transformed into a highwayman. A loose white linen shirt open halfway down a chest that would justify a much longer book, sleeves rolled to the elbow. A worn leather belt. And a long charcoal greatcoat with the collar turned up, swinging around his legs. The mask is still pushed up in his curls."

    a "You kept the mask."

    r "You drew it on me. It's the only thing I've got that's mine."

    "He looks you over, slowly. Then again, slower."

    r "Hands in the pockets."

    show ash laugh

    a "They're good pockets. Not sewn shut, deep enough to put more than a single coin in."

    show rob soft

    r "Worth it. Thirty-six years of running. All worth it."

    show rob neutral

    r "Your turn. You get a wish too. Something for you. Out loud."

    show ash neutral

    "The bush waits, glowing. You feel absurdly shy. You are a forty-year-old university professor standing in front of a shrub."

    menu:
        "\"Cheesecake. A real New York cheesecake.\"":
            $ c2_wish = "cheesecake"
            "A branch dips under the sudden weight of a perfect slice of cheesecake on a little china plate, with a fork. Dense, pale, the crust graham-cracker brown."
            show ash smile
            "You eat it standing up in velvet in a magic garden, and it's the best cheesecake you've ever had, and you save the last bite to be the most delicious thing, because that's the rule."
            show rob laugh
            r "You saved the last bite."
            a "That's the {i}rule.{/i}"
            r "I know. I've been waiting thirty-six years to watch you do it in person."
        "\"A whisky sour. Real egg white. And I didn't have to shake it.\"":
            $ c2_wish = "sour"
            "A crystal coupe ripens on a branch, frosted with cold, foam piled on top like the bush had notes about your technique. You sip. It's perfect. Your forearms, which shook your last one, feel a little put out."
            show rob laugh
            r "You wished for a drink."
            show ash wry
            a "I wished for a drink {i}I didn't have to make.{/i} That's not a drink. That's a vacation."
        "\"I want to know what 'smile waves' means.\"":
            $ c2_wish = "smile"
            $ sp()
            "The bush thinks about it. A small paper parcel grows, no bigger than a fortune cookie, tied with a white thread. Inside is a slip of paper in your own handwriting, which is unsettling, saying only: {i}Wait for it.{/i}"
            show rob laugh
            r "Ha. Even the bush won't tell you."
            show ash surprised
            a "My own shrub is withholding from me."
            r "It's not withholding. It's {i}foreshadowing.{/i} You'll like it."

    $ music("problem")
    $ whistle(1.0, 2)

    show stop angry at stoppos behind rob, ash with quickdiss

    st "{size=+8}STOP!{/size}"

    "The Constable fills the garden gate like a navy-blue door filling a doorframe. He's red. He's puffing. His whistle is in his teeth and one gloved hand is held out flat, the universal gesture of a man who expects the world to halt."

    show stop angry at stoppos_l

    show ash surprised
    
    st "That's quite enough running, sir. And you, madam, should know better. It's late. You'll catch your death in that frock."

    show ash wry

    a "It has pockets."

    st "Be that as it may."

    a "And it's lined with sunshine."

    "His mouth does several things fishes' mouths do before settling into a firm line."

    hide stop with quickdiss

    "He starts forward across the flagstones. The gate's the only way out. The walls are brick and ivy, high as the second floor."

    "And from the top of the wall, close by your left ear, something says:"

    $ music_stop(1.0)

    "{i}Mer-uh. Iht iht iht.{/i}"

    "You stop breathing."

    $ music("heart full")
    show squat neutral at squatpos with dissolve

    "An orange tabby sits on top of the wall. Built like a loaf of bread that does cardio when it suits. A white chin, white socks, ginger stripes like somebody drew them on with a marker, and big amber eyes that look straight at you with that particular expression of a cat who has been waiting for you to get the joke for a while now."

    show squat meow

    "He makes the sound again. {i}Mer-uh, iht iht iht.{/i} The chirp. The sound you've never once been able to describe to anyone, the one that meant, roughly, {i}hello, attention please, also I'm clever.{/i}"

    show ash sad

    a "Squatty?"

    "Squat Box blinks at you, slow. Then he hops down off the wall and lands with a thump that is entirely the fault of his own center of gravity. He trots to a gap in the ivy you hadn't seen, looks back at you over one shoulder, and waits."

    show squat neutral

    show rob soft

    r "He turned up quite a while ago. Just walked in one day like he'd been called. Knows the Margin better than I do."

    "Quieter:"

    r "He's been looking out for you. Same as me. Well, better. He's a cat."

    "Behind you, boots on flagstones."

    "You go through the ivy. You'd follow that cat anywhere. You always would have."

    hide squat
    hide rob
    hide ash
    with fadeout

    "A crawlspace behind the ivy, damp and green and smelling of wet wood, which is a smell you've always said almost makes up for wet dog."
    
    "A tunnel of brick. A courtyard. A stair. Squat Box trots ahead of you the whole way at the exact pace of a cat who could go faster and is choosing not to, tail straight up like a flag."

    "And then you're back in the lane, a long way down from the garden, under the arch of trees, the lamps glowing, the Constable's whistle somewhere far behind and getting farther."

    $ light("night")
    scene bg street night with dissolve
    show ash sad at lpos
    show rob neutral at gpos
    show squat neutral at squatpos
    with dissolve

    "Squat Box sits down in the middle of the cobbles and looks up at you, expectantly."

    "[rob_name] reaches into his coat, comes out with a little sparkly ball, and holds it out to you without a word. Of course he has one. He's a thief drawn from pure whimsy. He probably has everything."

    show ash soft

    a "A squatty ball!"

    "You accept it. It sits lightly in your hand, soft and a little scratchy where the sparkly threads sit like tinsel."

    $ c2_squat_seen = set()
    $ c2_squat_more = True
    while c2_squat_more and len(c2_squat_seen) < 3:
        menu:
            "Throw it for him." if "fetch" not in c2_squat_seen:
                $ c2_squat_seen.add("fetch")
                if c2_squat is None:
                    $ c2_squat = "fetch"
                "You toss the ball down the cobbles. Squat Box takes off after it, low and fast, pooch waggling back and forth. The way he used to cross your old apartment floor, all business."
                show squat ball
                "He bats it once to make sure it's dead, or just for fun, picks it up in his teeth. He trots back on little prancing paws, and drops it on your foot."
                "Fetch. The cat played fetch. Insistently. Adorably. People often didn't believe it."
                show ash laugh
                a "{i}Thank you.{/i} Thank you, buddy. Who's a clever boy."
                "{i}Iht iht.{/i} Obviously he is."
            "Kneel down and say his name." if "kneel" not in c2_squat_seen:
                $ c2_squat_seen.add("kneel")
                if c2_squat is None:
                    $ c2_squat = "kneel"
                "You kneel on the cobbles in your velvet and don't care."
                a "Hey, Squatty B."
                "He steps in close, and presses the top of his head into your chin, hard, the way he always did, like a small orange battering ram of love. He smells like a sunny windowsill. He smells exactly right."
            "Ask him if he's been drinking out of the toilet." if "toilet" not in c2_squat_seen:
                $ c2_squat_seen.add("toilet")
                if c2_squat is None:
                    $ c2_squat = "toilet"
                show ash wry
                a "Have you been drinking out of the toilet again? Don't lie to me."
                "Squat Box gives you a look of perfect, unbothered guilt. He has, absolutely, been drinking out of some toilet, somewhere in the Margin, and he'd do it again."
                show ash laugh
                "You laugh so hard and so suddenly it comes out wet."
            "Keep moving. There's a chase on, after all." if c2_squat_seen:
                $ c2_squat_more = False

    "Then he does what he always did. He brushes against your leg, cheek to flank, warm, solid, and proprietary."

    "You don't move. You let him. You let it be what it is, which is the best thing that has ever happened in the vicinity of your feet."

    show squat purr

    show rob soft

    "[rob_name] doesn't say anything. He stands on the other side of the cat with his hands in his greatcoat pockets and an unbearably soft look on his face."

    "After a while, Squat Box stands, stretches front and back with enormous ceremony, chirps once more, and trots off up the lane into the dark under the trees, tail high."

    show squat ball

    show ash sad

    a "Wait..."

    r "He does that. He'll be back when you need him. That's sort of his whole thing here."

    "You watch the place he went. You breathe in. You breathe out. Something in your chest that's been closed for a while is open now, and it hurts the way stretching hurts. The good way."

    hide squat with fadeout

    show ash neutral

    a "Is everyone I've lost here?"

    show rob neutral

    "He thinks about it, which you appreciate. He doesn't just say yes."

    r "No. Just what you loved and didn't finish with. Nobody's ever finished with a cat. And things you started. Like me."

    show ash wry

    a "Must be crowded."

    show rob laugh

    r "You have no idea."

    show ash neutral

    "Except you do. You have a very clear idea of how many things you started and didn't finish. Hell, you started four just in the past week."

    show rob neutral

    show ash neutral

    $ music("tentative sweet")

    "You walk. The lane slopes down toward a stone bridge, the trees lean in overhead, and the gas lamps make a warm path in front of you and a warm path behind."

    "He walks close. Not quite touching. His coat brushes your skirt now and then, and every time it does, you notice."

    show ash smile

    a "So what's your plan? Before dawn. How do I write you an ending?"

    show rob wry

    r "I don't have a plan. I've never needed one. My entire character is a back leg."

    a "You must want {i}something.{/i}"

    show rob neutral

    "He's quiet for a few steps."

    r "I'd like to stop running. I'd like to turn around and see what's behind me. Thirty-six years, Crayon, and I've never seen my own face in the drawing."

    "He shrugs, a big, careful shrug."

    r "And I'd like it to be something you'd want to read. That's the selfish part."

    show ash soft

    a "That doesn't sound selfish."

    r "You haven't seen what I want to happen in it."

    "He says it lightly. His eyes say it darkly, with a cliché about desire you do your best never to write."

    "Then the lamp beside you brightens."

    $ music("affinity")

    "Not much. A little flare, a warm extra glow, like it just heard something nice. And then the lamp after it brightens. And the one after that."
    
    "Down the lane, one by one, the gas lamps flare and settle, flare and settle, and the stained-glass windows catch it and glow brighter one after the other, and the leaves on the trees shiver gold in sequence, a ripple of light running all the way down the street and over the bridge and out of sight."

    show ash surprised

    a "What was that?"

    if c2_wish == "smile":
        show rob laugh
        r "That's the bit the bush wouldn't tell you."
        a "That's a {i}smile wave?{/i}"
    else:
        show rob smile
        r "That? That's a smile wave."
        a "{i}That's{/i} a smile wave?"

    show rob soft

    r "You wrote it down in February and forgot what it meant. The Margin didn't like that. So it decided for you."
    
    r "When something lovely happens, the nearest light smiles, and the next one catches it, and the next, all the way down the street. It's how news travels here."

    a "What lovely thing happened?"

    r "You smiled at me."

    show ash flustered

    "You didn't know you had."

    "Now you can't stop smiling."

    "And as the smile wave runs out of sight over the bridge, something cold touches your cheekbone."

    $ music("sweet romance")
    $ light("night")
    show bg street snow with longdiss

    "Snow."

    "The first snow of the season. Big, fat, lazy flakes, the kind that take their sweet time getting to the ground, drifting down through the lamplight like they've got nowhere to be."
    
    "Around you, they land on the cobbles and stay, and in a minute there's a fine glittering dusting on everything, the stones, the lamp tops, the balconies, the red and gold leaves."
    
    "And even though it's an entirely different kind of snow, the sparkle snow settles onto every surface and throws the lamplight back a hundredfold."

    "Snowticipation. Every year you wait for it. And here it is, early, on the night before your birthday, on a street you built out of things you were grateful for."

    "A flake lands in your eyelashes and stays. You're aware that you probably look dumb as hell. You feel like the epitome of ephemeral beauty anyway. Both things are true. Both have always been true."

    show rob soft

    "[rob_name] has stopped walking. The snow is landing in his curls and on the shoulders of his coat. He's looking at you like the snowflake in your lashes is the only thing in the Margin."

    r "You're cold."

    a "I'm fine. I have pockets and sunshine."

    "He unbuttons his greatcoat anyway, slides it off, and settles it around your bare shoulders. It's huge. It's warm from him. It smells of linseed and wood smoke and, faintly, of crayon."

    "He doesn't take his hands off the lapels."

    menu:
        "Kiss him.":
            $ c2_kiss = "you"
            $ sp()
            "You've spent a lot of years waiting for the right person to make the first move. You're forty-one in about twenty minutes. You've stopped waiting for things."
            "You take a fistful of his shirt and pull him down to you."
        "Wait. Let him ask.":
            $ c2_kiss = "ask"
            "You don't move. You look up at him through the snow and let him see that you're not going anywhere."
            show rob neutral
            r "Can I..."
            a "Yes."
            r "I didn't finish."
            a "You don't have to. The foreshadowing was pretty clear."
        "\"Thirty-six years and you've never stolen a kiss?\"":
            $ c2_kiss = "dare"
            $ sp()
            show ash wry
            a "Thirty-six years a thief and you've never stolen a kiss? Some robber."
            show rob laugh
            r "I've never stolen anything that wanted to be taken."
            a "Then this'll be a first."
            "He laughs, low, and the laugh is still in his mouth when it finds yours."

    $ cg("cg street kiss", longdiss)

    "His mouth is warm and his lip is cold where the snow has caught it. One hand slides up from the lapel of the coat to cradle your jaw, his thumb resting just under your ear; the other goes to the small of your back, inside the coat."
    
    "He pulls you in until there's no air for the snow to fall through."

    "You've got both hands fisted in his white linen shirt. You're not sure who's holding up whom."

    "He kisses like a man who has had a very long time to think about it and has decided to take his time. Slow. Thorough. Curious."
    
    "He kisses the corner of your mouth like he's checking it was real and then comes back to the middle of it like he's sure."

    show screen lamp_pulse

    "Snowflakes land on your eyelids. You keep your eyes shut. Somewhere a lamp flares, and then the next one, and the next, and you know without looking that the whole street is smiling."

    "When he finally pulls back, it's only an inch. His forehead rests against yours. His breath is warm on your mouth."

    "You place his coat back on his shoulders. He gives you a questioning look."

    $ light("night")
    scene bg street snow
    show ash heated at lpos
    show rob heated at gpos
    with dissolve

    a "You deserve to be warm, too. Also, continuity."

    "He looks at your lips again."

    r "Crayon."

    a "Hm."

    r "I've been wanting to do that since you were about twenty-six. Before that it would have been strange."

    show ash laugh
    show rob laugh

    hide screen lamp_pulse
    with Dissolve(1.5)

    "You laugh into his chin. He laughs into your hair. It's the stupidest, best moment of your year and it isn't even your birthday yet."

    $ music("problem")
    $ whistle(0.85)

    show stop angry at stoppos behind rob, ash with quickdiss

    st "{size=+8}STOP!{/size}"

    "At the top of the lane, the Constable. Snow on his helmet. Snow on his moustache. A lot less snow on the ground where he's standing, because he's stamping."

    show stop angry at stoppos_l

    st "Thirty-six years! Thirty-six years I have chased this man across every page you ever left open, madam, and he has never, ever, once stopped to {i}canoodle!{/i}"

    show rob laugh

    r "Fair. That's fair. That's new."

    "[rob_name] takes your hand. You run. Downhill, which is easier than uphill, and you'd like to thank gravity again for pulling its weight."
    
    "Your skirt swishes magnificently and your socks are soaking and you're laughing too hard to run straight."

    hide stop
    hide rob
    hide ash
    with fadeout

    "Halfway to the bridge, [rob_name] yanks you sideways into a doorway: a deep Venetian arch, carved stone tracery blooming overhead, a door that hasn't opened in years."
    
    "He pulls you into the shadow and against his chest and wraps his coat and his arms around you both, and you stand frozen and listen to the Constable's boots come stamping down the lane."

    stop music fadeout 2.0
    scene black with blackfade

    ## Interlude: the Robber
    call pov_card(rob_name)
    $ music("gentle longing")
    $ light("night")
    scene bg street snow with longdiss

    "He's holding her in a doorway, and his heart is going like he's been running, which he has, for thirty-six years, but not like this."

    "Her head is tucked under his chin. The top of it smells like snow and roses, and, faintly, of whisky. She's shaking a little, from cold or laughing or both."
    
    "Her hand is flat on his chest, right on the place where his heart is making a fool of him, and she must be able to feel it. He doesn't mind. Let her."

    "The Constable stamps past the mouth of the arch, puffing, muttering about subsection four, and on down toward the bridge."

    "He doesn't let go of her."

    "Here's the thing he hasn't told her."

    "From this side, the almond blossoms are a window. He found that out years ago, long before she hung the scrolls, long before the cat came, back when there was another room, another painting."
    
    "His running took him past them. He'd stopped, which he never did. And he'd looked through."

    "He saw a woman alone in a warm room."

    "He saw her come home from school. Come home from waitress jobs. From office jobs. From university. Then from fancier university, which he only vaguely understood the purpose of."
    
    "And then from teaching. He thought that was funny. When she'd drawn him to life, half off the page, she had wanted to be a teacher. Like Mrs. Peterson. She was five and she knew that."
    
    "And then he watched her take about twenty-five years to get right back there. It was worth the trip. A round trip usually is. You come back different, even when you arrive back at the same place."
    
    "Through the almond blossoms, she'd set down her bag, and stand in the middle of the floor for a second with her face tipped up and her eyes closed. The way she does in sunlight, the way her mother does, and her grandmother did."
    
    "He saw her sing along to her music, badly, joyfully, outrunning every correct note like it was the cops. He saw her slide across the floor in her socks. He saw her eat ramen in lingerie and play games and talk back to the television and cry at a movie and laugh at her own jokes, alone, to an empty room, and then write a line in her notebook about something small and good."

    "He saw her write a whole novel on that couch. Then another. He saw her post them and wait, and check, and wait. He saw her put the phone face down."

    "He has been in love with her for longer than is reasonable for a crayon drawing, and he has never once been on the right side of the glass."

    "The sack is still on his shoulder. He can feel the corner of the journal through the canvas. Her kindergarten journal, stapled, before she'd graduated to the plastic spiral binding."
    
    "Taken from the Constabulary's evidence locker three hours ago. The page with the cop and the worm and the back of him. And underneath the drawing, the lined half. Blank."

    "She never wrote on it. She went on to fill a thousand other pages, and she never once went back to his."

    "He has no idea what she'll write. That's the terrible part. That's the part that makes it worth it."

    "She lifts her head from his chest. Her cheeks are pink from the cold. There's still snow in her lashes, and she knows it, and she's not doing anything about it. Because she's never in her life brushed a snowflake off her eyelashes, unless her mascara wasn't waterproof."

    a "Is he gone?"

    "He should say yes. He opens his mouth to."

    $ music_stop(0.5)
    $ whistle(0.55)

    st "I know you're in there, sir."

    "Right outside the arch. Patient. Tired. Close enough to touch."

    st "I've known for thirty-six years exactly where you'd be. You always run straight. I'd only have to wait."

    "[rob_name] looks down at the woman in his arms. She looks up at him."

    "For the first time in his life, he doesn't want to run straight."

    stop music fadeout 2.0
    scene black with blackfade
    return
