## Off the Page: shared definitions. No story text in this file.

default persistent.show_notices = True
default mc = "Ashley"
default rob_name = "The Robber"

init python:
    _O = [(2, "#00000088", 0, 0)]

    ## Whoever is speaking gets a very slight lift in brightness; narration leaves everyone as lit.
    def spk(tag):
        def cb(event, interact=True, **kwargs):
            if event == "begin":
                store.speaking = tag
        return cb

    def Left(name, color="#f3d98b", tag="ash"):
        return Character(name, color=color, who_outlines=_O, callback=spk(tag),
                         window_background=Image("gui/textbox_ash.png", xalign=0.5, yalign=1.0))
    def Right(name, color, tag=None, tint=None):
        bg = Transform("gui/textbox_other.png", xalign=0.5, yalign=1.0,
                       matrixcolor=(TintMatrix(tint) if tint else IdentityMatrix()))
        return Character(name, color=color, who_outlines=_O, callback=spk(tag), window_background=bg)

define a    = Left("[mc]")
define r    = Right("[rob_name]", "#e0e0e0", tag="rob")
define st   = Right("The Constable", "#f0a59c", tag="stop", tint="#ffd2cc")
define w    = Right("Go", "#a8e88a", tag="worm", tint="#d6f5c8")
define mom  = Right("Mom", "#f0b6c8")
define narrator = Character(None, callback=spk(None))
define txt  = Character(None, what_italic=True, what_color="#cfe3ff", callback=spk(None))

## --- State -------------------------------------------------------------------
default sprite_light = None
default speaking = None
default ash_outfit = "home"
default rob_outfit = "stripes"
default stop_outfit = "uniform"
default squat_outfit = "sit"
default worm_outfit = "apple"

default spark = 0

init python:
    import re

    def sp(n=1):
        store.spark += n

    EXPRS = ["neutral", "smile", "laugh", "wry", "soft", "surprised", "angry", "sad", "flustered", "heated", "tired", "ball", "meow", "purr", "run"]

    LIGHTS = {
        "dusk":  TintMatrix("#ffdcc8") * BrightnessMatrix(-0.03),
        "night": TintMatrix("#b4c0ea") * BrightnessMatrix(-0.10) * SaturationMatrix(0.92),
        "fire":  TintMatrix("#ffe2c2") * BrightnessMatrix(-0.03),
        "dawn":  TintMatrix("#ffe6cf") * BrightnessMatrix(-0.01),
        "dim":   TintMatrix("#a9b2d6") * BrightnessMatrix(-0.16) * SaturationMatrix(0.85),
        "moon":  TintMatrix("#c4d0f2") * BrightnessMatrix(-0.06) * SaturationMatrix(0.95),
    }
    def light(name=None):
        store.sprite_light = name

    def cg(name, trans=None):
        if renpy.loadable("images/cg/%s.webp" % name):
            renpy.scene()
            renpy.show(name)
            persistent.cg_seen.add(name)
            renpy.with_statement(trans or dissolve)
            return True
        return False

    SPRITE_SCALE = {}
    SPEAK_LIFT = BrightnessMatrix(0.05) * SaturationMatrix(1.03)

    def _spr(char, expr):
        def f(st, at):
            outfit = getattr(store, char + "_outfit", "")
            for cand in ("images/sprites/%s %s %s.webp" % (char, outfit, expr),
                         "images/sprites/%s %s neutral.webp" % (char, outfit)):
                if renpy.loadable(cand):
                    if outfit and (char + " " + outfit) not in persistent.seen_outfits:
                        persistent.seen_outfits.add(char + " " + outfit)
                    kw = {}
                    if (char + " " + outfit) in SPRITE_SCALE:
                        kw["zoom"] = SPRITE_SCALE[char + " " + outfit]
                    m = LIGHTS.get(store.sprite_light)
                    if char == store.speaking:
                        m = (m * SPEAK_LIFT) if m is not None else SPEAK_LIFT
                    if m is not None:
                        kw["matrixcolor"] = m
                    return (Transform(cand, **kw) if kw else cand), None
            return Null(), None
        return DynamicDisplayable(f)

    for _c in ("ash", "rob", "stop", "squat", "worm"):
        for _e in EXPRS:
            renpy.image((_c, _e), _spr(_c, _e))

    _music = {}
    for _f in renpy.list_files():
        _m = re.match(r"audio_music/.*\[(.+)\]\.ogg$", _f)
        if _m:
            _music[_m.group(1)] = _f

    def music(tag, fadein=2.0, fadeout=2.0):
        f = _music.get(tag)
        if f is None:
            return
        if renpy.music.get_playing() != f:
            renpy.music.play(f, fadein=fadein, fadeout=fadeout, loop=True)

    def music_stop(fadeout=2.5):
        renpy.music.stop(fadeout=fadeout)

    ## The Constable's whistle, at a volume that fits how far away he is, and blown more than once if he means it.
    def whistle(vol=1.0, times=1):
        f = "audio_sfx/whistle.ogg"
        if renpy.loadable(f):
            renpy.sound.play([f] * times, relative_volume=vol)

    ## Emoji are drawn from Ren'Py's built-in Twemoji font. In italic text (the phone messages) Ren'Py would try
    ## to slant that color font, and the emoji vanish, so emoji always use the upright face.
    for _b in (False, True):
        for _it in (False, True):
            config.font_replacement_map[("TwemojiCOLRv0.ttf", _b, _it)] = ("TwemojiCOLRv0.ttf", False, False)

    def sfx(name):
        f = "audio_sfx/%s.ogg" % name
        if renpy.loadable(f):
            renpy.sound.play(f)

## --- Staging -----------------------------------------------------------------
## You stand left and face right; everyone else stands right and faces left.
transform lpos:
    xanchor 0.5 xpos 0.23 yanchor 1.0 ypos 1160 zoom 0.79
transform rpos:
    xanchor 0.5 xpos 0.77 yanchor 1.0 ypos 1160 zoom 0.80
transform gpos:
    xanchor 0.5 xpos 0.76 yanchor 1.0 ypos 1160 zoom 0.84
transform cpos:
    xanchor 0.5 xpos 0.52 yanchor 1.0 ypos 1160 zoom 0.80
transform farright:
    xanchor 0.5 xpos 0.86 yanchor 1.0 ypos 1170 zoom 0.80
## The Constable stands between you and the Robber, a little behind. His art faces right (toward the Robber);
## stoppos_l turns him to face you. Every transform sets xzoom so a flip never sticks.
transform stoppos:
    xanchor 0.5 xpos 0.50 yanchor 1.0 ypos 1140 zoom 0.74 xzoom 1.0
transform stoppos_l:
    xanchor 0.5 xpos 0.50 yanchor 1.0 ypos 1140 zoom 0.74 xzoom -1.0
## Squat Box on his perch, raised above the text box.
transform squatpos:
    xanchor 0.5 xpos 0.50 yanchor 1.0 ypos 1080 zoom 0.62 xzoom 1.0
## Go on his branch. The art faces right; the _l versions face left (toward you).
transform wormpos:
    xanchor 0.5 xpos 0.52 yanchor 1.0 ypos 1150 zoom 0.66 xzoom 1.0
transform wormpos_l:
    xanchor 0.5 xpos 0.52 yanchor 1.0 ypos 1150 zoom 0.66 xzoom -1.0
transform wormpos_mid_l:
    xanchor 0.5 xpos 0.40 yanchor 1.0 ypos 1150 zoom 0.62 xzoom -1.0
## The Robber's side view: he runs off the right edge and stops where the kindergarten drawing has him,
## only his back leg, the sack and a bit of him still on the page. Drawn smaller, as if a step further back.
transform runoff:
    xanchor 0.5 yanchor 1.0 ypos 1325 zoom 1.05 xzoom 1.0 xpos 0.62
    pause 0.3
    easein 0.9 xpos 0.97
## A slow golden pulse over the scene (under the text box), for the lamps smiling down the lane.
transform lamp_glow:
    blend "add"
    alpha 0.0
    linear 1.8 alpha 0.10
    block:
        linear 2.4 alpha 0.03
        linear 2.4 alpha 0.11
        repeat
screen lamp_pulse():
    zorder -5
    add Solid("#ffbf55") at lamp_glow
transform catpos:
    xanchor 0.5 xpos 0.50 yanchor 1.0 ypos 1095 zoom 0.40
transform wormpos:
    xanchor 0.5 xpos 0.55 yanchor 1.0 ypos 1085 zoom 0.55
transform wormshoulder:
    xanchor 0.5 xpos 0.60 yanchor 1.0 ypos 700 zoom 0.40
transform dimbg:
    matrixcolor TintMatrix("#a7b1d1") * BrightnessMatrix(-0.14)
transform shake:
    linear 0.05 xoffset -8
    linear 0.05 xoffset 8
    linear 0.05 xoffset -5
    linear 0.05 xoffset 0

define slowfade  = Fade(0.8, 0.5, 1.0)
define blackfade = Fade(1.2, 0.9, 1.4)
define whitefade = Fade(0.6, 0.4, 1.2, color="#fff")
define quickdiss = Dissolve(0.25)
define fadeout   = Dissolve(0.8)
define longdiss  = Dissolve(2.5)

image black = Solid("#000")

## A small card before a change of point of view.
label pov_card(who):
    scene black with dissolve
    show text "{size=30}{color=#8a8a8a}{i}meanwhile{/i}{/color}{/size}\n\n{size=56}{color=#d9a65b}[who]{/color}{/size}" at truecenter with dissolve
    pause
    hide text with dissolve
    return

label chapter_card(num, title):
    $ music_stop()
    scene black with slowfade
    show text "{size=40}{color=#d9a65b}[num]{/color}{/size}\n\n{size=88}[title]{/size}" at truecenter with dissolve
    pause
    hide text with dissolve
    return
